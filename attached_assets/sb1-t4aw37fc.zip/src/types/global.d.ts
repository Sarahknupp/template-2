declare global {
  interface Window {
    // Define global window extensions if needed
  }
}

export {};