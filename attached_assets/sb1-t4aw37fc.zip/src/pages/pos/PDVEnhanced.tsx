import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  // Icons for main actions
  ShoppingCart, DollarSign, Package, Users, File, Plus, Minus, 
  Trash2, Search, CreditCard, Clock, FileText, BarChart2, FileDigit, 
  
  // Icons for advanced features
  Settings, Printer, CreditCard as CardIcon, 
  DollarSign as Cash, Inbox, ArrowDownCircle, ArrowUpCircle,
  RefreshCw, CheckCircle, XCircle, AlertTriangle, ChevronDown, 
  
  // Icons for categories and navigation
  Coffee, Utensils, ShoppingBag, Pizza, Cake, Book, Gift, Heart,
  
  // Interface elements
  LogOut, Menu, X, User, Lock, Activity, Eye
} from 'lucide-react';

// UI Components
import { Button } from '../../components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../../components/ui/dialog';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';

// Mock data
import { mockProducts, mockCustomers, mockSales } from '../../data/mockData';
import toast from 'react-hot-toast';

// Type definitions
import { Product } from '../../types/product';
import { SaleItem } from '../../types/sale';

export const PDVEnhanced: React.FC = () => {
  const navigate = useNavigate();
  const searchInputRef = useRef<HTMLInputElement>(null);
  
  // State management
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [cashierStatus, setCashierStatus] = useState<'open' | 'closed'>('open');
  const [cashierBalance, setCashierBalance] = useState(500.00); // Initial balance
  const [activeSidePanel, setActiveSidePanel] = useState<'cart' | 'customer' | 'products'>('cart');
  
  // Dialogs state
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isNFCeModalOpen, setIsNFCeModalOpen] = useState(false);
  const [isNFeModalOpen, setIsNFeModalOpen] = useState(false);
  const [isCashierModalOpen, setIsCashierModalOpen] = useState(false);
  const [isWithdrawalModalOpen, setIsWithdrawalModalOpen] = useState(false);
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isTEFModalOpen, setIsTEFModalOpen] = useState(false);
  const [isProductSearchModalOpen, setIsProductSearchModalOpen] = useState(false);
  
  // Payment processing state
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('');
  const [paymentStep, setPaymentStep] = useState<number>(1);
  const [cashReceived, setCashReceived] = useState<string>('');
  const [installments, setInstallments] = useState(1);
  const [cardType, setCardType] = useState<'credit' | 'debit'>('credit');
  
  // Cash operations 
  const [operationAmount, setOperationAmount] = useState('');
  const [operationReason, setOperationReason] = useState('');
  
  // Settings
  const [settingsTab, setSettingsTab] = useState<'general' | 'fiscal' | 'interface' | 'users'>('general');
  
  // TEF settings
  const [tefProvider, setTefProvider] = useState('stone');
  const [tefStatus, setTefStatus] = useState<'connected' | 'disconnected' | 'processing'>('connected');
  
  // Corporate logo
  const [companyLogo, setCompanyLogo] = useState<string | null>(null);
  const [companyName, setCompanyName] = useState('ControlAI');
  
  // Load company logo on component mount
  useEffect(() => {
    // In a real app, you would fetch this from an API or localStorage
    const storedLogo = localStorage.getItem('companyLogo');
    if (storedLogo) {
      setCompanyLogo(storedLogo);
    }
    
    // Focus on search input when component mounts
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
    
    // Setup key bindings
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F2') {
        e.preventDefault();
        if (searchInputRef.current) {
          searchInputRef.current.focus();
        }
      } else if (e.key === 'F3') {
        e.preventDefault();
        setIsProductSearchModalOpen(true);
      } else if (e.key === 'F4') {
        e.preventDefault();
        handleNewSale();
      } else if (e.key === 'F8' && cart.length > 0) {
        e.preventDefault();
        setIsPaymentModalOpen(true);
      } else if (e.key === 'F9') {
        e.preventDefault();
        setIsNFCeModalOpen(true);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [cart]);
  
  // Get unique categories from products
  const productCategories = [...new Set(mockProducts.map(product => product.category))];
  
  // Filter products based on search term and category
  const filteredProducts = mockProducts.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !activeCategory || product.category === activeCategory;
    return matchesSearch && matchesCategory && product.isActive;
  });
  
  // Cart operations
  const addToCart = (product: Product) => {
    const existingItem = cart.find(item => item.productId === product.id);
    
    if (existingItem) {
      setCart(
        cart.map(item => 
          item.productId === product.id
            ? { ...item, quantity: item.quantity + 1, total: (item.quantity + 1) * item.unitPrice }
            : item
        )
      );
    } else {
      setCart([
        ...cart,
        {
          productId: product.id,
          productName: product.name,
          quantity: 1,
          unitPrice: product.price,
          total: product.price
        }
      ]);
    }
    
    toast.success(`${product.name} adicionado`);
  };
  
  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart(cart.filter(item => item.productId !== productId));
      return;
    }
    
    setCart(
      cart.map(item =>
        item.productId === productId
          ? { ...item, quantity, total: quantity * item.unitPrice }
          : item
      )
    );
  };
  
  const removeItem = (productId: string) => {
    setCart(cart.filter(item => item.productId !== productId));
  };
  
  const getSubtotal = () => {
    return cart.reduce((sum, item) => sum + item.total, 0);
  };
  
  const getTax = () => {
    // Simplified tax calculation - 9% of subtotal
    return getSubtotal() * 0.09;
  };
  
  const getTotal = () => {
    return getSubtotal() + getTax();
  };
  
  const handleNewSale = () => {
    setCart([]);
    setSearchTerm('');
    setSelectedCustomer(null);
    setCashReceived('');
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };
  
  const handleSelectCustomer = (customer: any) => {
    setSelectedCustomer(customer);
    setActiveSidePanel('cart');
    toast.success(`Cliente ${customer.name} selecionado`);
  };
  
  // Handle payment processing
  const handlePayment = () => {
    if (!selectedPaymentMethod) {
      toast.error('Selecione um método de pagamento');
      return;
    }
    
    if (selectedPaymentMethod === 'cash' && !cashReceived) {
      toast.error('Informe o valor recebido');
      return;
    }
    
    // In a real app, this would be an API call
    const saleData = {
      id: `SAL-${new Date().getTime()}`,
      date: new Date(),
      items: cart,
      subtotal: getSubtotal(),
      tax: getTax(),
      total: getTotal(),
      paymentMethod: selectedPaymentMethod,
      status: 'completed',
      cashierId: '1', // Mock user ID
      customerDetails: selectedCustomer ? {
        name: selectedCustomer.name,
        phone: selectedCustomer.phone,
        email: selectedCustomer.email,
      } : undefined,
    };
    
    console.log('Sale completed:', saleData);
    
    // Update cashier balance
    if (selectedPaymentMethod === 'cash') {
      setCashierBalance(prev => prev + getTotal());
    }
    
    toast.success('Venda realizada com sucesso!');
    setIsPaymentModalOpen(false);
    
    // Show change dialog if cash payment
    if (selectedPaymentMethod === 'cash') {
      const change = parseFloat(cashReceived) - getTotal();
      if (change > 0) {
        toast.success(`Troco: R$ ${change.toFixed(2)}`, { duration: 5000 });
      }
    }
    
    // Reset state
    handleNewSale();
  };
  
  // Handle fiscal document emission
  const handleNFCeEmission = () => {
    // In a real app, this would trigger NFCe emission
    toast.success('NFCe emitida com sucesso!');
    setIsNFCeModalOpen(false);
  };
  
  const handleNFeEmission = () => {
    // In a real app, this would trigger NFe emission
    toast.success('NFe emitida com sucesso!');
    setIsNFeModalOpen(false);
  };
  
  // Handle cashier operations
  const handleOpenCashier = () => {
    setCashierStatus('open');
    toast.success('Caixa aberto com sucesso!');
    setIsCashierModalOpen(false);
  };
  
  const handleCloseCashier = () => {
    setCashierStatus('closed');
    toast.success('Caixa fechado com sucesso!');
    setIsCashierModalOpen(false);
  };
  
  const handleCashWithdrawal = () => {
    const amount = parseFloat(operationAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Informe um valor válido');
      return;
    }
    
    if (amount > cashierBalance) {
      toast.error('Saldo insuficiente para esta operação');
      return;
    }
    
    if (!operationReason) {
      toast.error('Informe o motivo da retirada');
      return;
    }
    
    // In a real app, this would be an API call
    setCashierBalance(prev => prev - amount);
    toast.success(`Retirada de R$ ${amount.toFixed(2)} realizada com sucesso`);
    setIsWithdrawalModalOpen(false);
    setOperationAmount('');
    setOperationReason('');
  };
  
  const handleCashDeposit = () => {
    const amount = parseFloat(operationAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Informe um valor válido');
      return;
    }
    
    if (!operationReason) {
      toast.error('Informe o motivo do suprimento');
      return;
    }
    
    // In a real app, this would be an API call
    setCashierBalance(prev => prev + amount);
    toast.success(`Suprimento de R$ ${amount.toFixed(2)} realizado com sucesso`);
    setIsDepositModalOpen(false);
    setOperationAmount('');
    setOperationReason('');
  };
  
  // TEF operations
  const handleTestTEF = () => {
    setTefStatus('processing');
    
    // Simulate processing
    setTimeout(() => {
      setTefStatus('connected');
      toast.success('Comunicação com TEF testada com sucesso!');
    }, 2000);
  };
  
  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency', 
      currency: 'BRL'
    }).format(value);
  };
  
  // Function to handle cashier closing
  const handleCashierOperation = (operation: 'open' | 'close') => {
    setIsCashierModalOpen(true);
    // Additional logic would be implemented here
  };
  
  // Function to handle logo upload
  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    if (file.size > 2 * 1024 * 1024) {
      toast.error('A imagem deve ter no máximo 2MB');
      return;
    }
    
    if (!['image/png', 'image/jpeg', 'image/jpg'].includes(file.type)) {
      toast.error('Apenas arquivos PNG, JPG e JPEG são permitidos');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setCompanyLogo(result);
      localStorage.setItem('companyLogo', result);
      toast.success('Logo atualizado com sucesso!');
    };
    reader.readAsDataURL(file);
  };
  
  // Create product category buttons with icons
  const categoryIcons: Record<string, React.ReactNode> = {
    'Produção Própria': <Cake className="h-5 w-5" />,
    'Matéria Prima': <Coffee className="h-5 w-5" />,
    'Produtos de Revenda': <ShoppingBag className="h-5 w-5" />
  };
  
  return (
    <div className="h-full flex flex-col">
      {/* Header with Corporate Branding */}
      <div className="bg-amber-700 p-3 flex items-center justify-between text-white">
        <div className="flex items-center space-x-4">
          {companyLogo ? (
            <img 
              src={companyLogo} 
              alt="Logo" 
              className="h-10 w-auto object-contain"
            />
          ) : (
            <div className="bg-amber-600 p-2 rounded">
              <ShoppingCart className="h-6 w-6" />
            </div>
          )}
          <h1 className="text-xl font-bold">{companyName} - PDV Avançado</h1>
        </div>
        
        <div className="flex items-center space-x-2">
          <div className={`px-3 py-1 rounded-full text-sm ${
            cashierStatus === 'open' 
              ? 'bg-green-800 text-white' 
              : 'bg-red-800 text-white'
          }`}>
            Caixa {cashierStatus === 'open' ? 'Aberto' : 'Fechado'}
          </div>
          
          <button 
            className="p-1 hover:bg-amber-800 rounded-full"
            onClick={() => navigate('/')}
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>
      </div>
      
      {/* Main Toolbar with Actions */}
      <div className="bg-gray-100 p-3 border-b border-gray-200 grid grid-cols-2 md:grid-cols-8 gap-2">
        <Button 
          className={`flex flex-col items-center justify-center h-16 p-1 ${
            cashierStatus === 'open' 
              ? 'bg-red-600 hover:bg-red-700' 
              : 'bg-green-600 hover:bg-green-700'
          } text-white`}
          onClick={() => handleCashierOperation(cashierStatus === 'open' ? 'close' : 'open')}
        >
          {cashierStatus === 'open' ? (
            <>
              <LogOut className="h-6 w-6 mb-1" />
              <span className="text-xs">Fechar Caixa</span>
            </>
          ) : (
            <>
              <LogOut className="h-6 w-6 mb-1" />
              <span className="text-xs">Abrir Caixa</span>
            </>
          )}
        </Button>
        
        <Button 
          className="flex flex-col items-center justify-center h-16 p-1 bg-amber-600 hover:bg-amber-700 text-white"
          onClick={() => setIsWithdrawalModalOpen(true)}
          disabled={cashierStatus === 'closed'}
        >
          <ArrowUpCircle className="h-6 w-6 mb-1" />
          <span className="text-xs">Sangria</span>
        </Button>
        
        <Button 
          className="flex flex-col items-center justify-center h-16 p-1 bg-amber-600 hover:bg-amber-700 text-white"
          onClick={() => setIsDepositModalOpen(true)}
          disabled={cashierStatus === 'closed'}
        >
          <ArrowDownCircle className="h-6 w-6 mb-1" />
          <span className="text-xs">Suprimento</span>
        </Button>
        
        <Button 
          className="flex flex-col items-center justify-center h-16 p-1 bg-amber-600 hover:bg-amber-700 text-white"
          onClick={() => setIsCancelModalOpen(true)}
          disabled={cashierStatus === 'closed'}
        >
          <XCircle className="h-6 w-6 mb-1" />
          <span className="text-xs">Cancelar</span>
        </Button>
        
        <Button 
          className="flex flex-col items-center justify-center h-16 p-1 bg-blue-600 hover:bg-blue-700 text-white"
          onClick={() => setIsNFCeModalOpen(true)}
          disabled={cashierStatus === 'closed'}
        >
          <FileDigit className="h-6 w-6 mb-1" />
          <span className="text-xs">NFCe (F9)</span>
        </Button>
        
        <Button 
          className="flex flex-col items-center justify-center h-16 p-1 bg-purple-600 hover:bg-purple-700 text-white"
          onClick={() => setIsTEFModalOpen(true)}
          disabled={cashierStatus === 'closed'}
        >
          <CardIcon className="h-6 w-6 mb-1" />
          <span className="text-xs">TEF</span>
        </Button>
        
        <Button 
          className="flex flex-col items-center justify-center h-16 p-1 bg-amber-600 hover:bg-amber-700 text-white"
          onClick={() => setIsProductSearchModalOpen(true)}
        >
          <Search className="h-6 w-6 mb-1" />
          <span className="text-xs">Produtos (F3)</span>
        </Button>
        
        <Button 
          className="flex flex-col items-center justify-center h-16 p-1 bg-gray-800 hover:bg-gray-900 text-white"
          onClick={() => setIsSettingsModalOpen(true)}
        >
          <Settings className="h-6 w-6 mb-1" />
          <span className="text-xs">Configurações</span>
        </Button>
      </div>
      
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-gray-50">
        {/* Left Side - Products */}
        <div className="md:w-2/3 flex flex-col overflow-hidden border-r border-gray-200">
          {/* Search Bar */}
          <div className="p-4 bg-white border-b border-gray-200">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                ref={searchInputRef}
                type="text"
                className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-lg"
                placeholder="Pesquisar produtos (F2)"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                disabled={cashierStatus === 'closed'}
              />
            </div>
          </div>

          {/* Category Buttons */}
          <div className="bg-white border-b border-gray-200 overflow-x-auto">
            <div className="p-2 flex space-x-2">
              <button
                className={`px-4 py-2 rounded-md text-sm font-medium flex items-center whitespace-nowrap ${
                  !activeCategory
                    ? 'bg-amber-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
                onClick={() => setActiveCategory(null)}
              >
                <ShoppingBag className="h-4 w-4 mr-1" />
                Todos
              </button>
              {productCategories.map((category) => (
                <button
                  key={category}
                  className={`px-4 py-2 rounded-md text-sm font-medium flex items-center whitespace-nowrap ${
                    activeCategory === category
                      ? 'bg-amber-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                  onClick={() => setActiveCategory(category)}
                >
                  {categoryIcons[category] || <Package className="h-4 w-4 mr-1" />}
                  {category}
                </button>
              ))}
            </div>
          </div>
          
          {/* Products Grid */}
          <div className="flex-1 overflow-auto p-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {cashierStatus === 'closed' ? (
              <div className="col-span-full flex flex-col items-center justify-center h-full text-gray-500">
                <XCircle className="h-16 w-16 mb-2 text-red-500" />
                <p className="text-xl font-medium">Caixa Fechado</p>
                <p className="mt-2">Abra o caixa para iniciar as operações de venda</p>
                <Button 
                  className="mt-4 bg-green-600 hover:bg-green-700"
                  onClick={() => handleCashierOperation('open')}
                >
                  Abrir Caixa
                </Button>
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center h-64 text-gray-500">
                <Package className="h-12 w-12 mb-2" />
                <p>Nenhum produto encontrado</p>
              </div>
            ) : (
              filteredProducts.map((product) => (
                <button
                  key={product.id}
                  className="bg-white rounded-lg shadow p-3 flex flex-col items-center hover:shadow-md transition-shadow text-center"
                  onClick={() => addToCart(product)}
                >
                  <div className="w-full h-24 mb-2 bg-gray-100 rounded-md flex items-center justify-center overflow-hidden">
                    {product.image ? (
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Package className="h-10 w-10 text-gray-400" />
                    )}
                  </div>
                  <h3 className="text-sm font-medium text-gray-900 mb-1 line-clamp-2">{product.name}</h3>
                  <p className="text-lg font-semibold text-amber-600">{formatCurrency(product.price)}</p>
                </button>
              ))
            )}
          </div>
        </div>
        
        {/* Right Side Panels */}
        <div className="md:w-1/3 border-l border-gray-200 flex flex-col bg-white overflow-hidden">
          {/* Panel Navigation */}
          <div className="flex border-b border-gray-200">
            <button 
              className={`flex-1 py-3 px-4 text-center font-medium ${
                activeSidePanel === 'cart' 
                  ? 'border-b-2 border-amber-500 text-amber-600' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setActiveSidePanel('cart')}
            >
              <div className="flex items-center justify-center">
                <ShoppingCart className="h-5 w-5 mr-1" />
                Carrinho
              </div>
            </button>
            
            <button 
              className={`flex-1 py-3 px-4 text-center font-medium ${
                activeSidePanel === 'customer' 
                  ? 'border-b-2 border-amber-500 text-amber-600' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setActiveSidePanel('customer')}
            >
              <div className="flex items-center justify-center">
                <Users className="h-5 w-5 mr-1" />
                Cliente
              </div>
            </button>
            
            <button 
              className={`flex-1 py-3 px-4 text-center font-medium ${
                activeSidePanel === 'products' 
                  ? 'border-b-2 border-amber-500 text-amber-600' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setActiveSidePanel('products')}
            >
              <div className="flex items-center justify-center">
                <Package className="h-5 w-5 mr-1" />
                Produtos
              </div>
            </button>
          </div>
          
          {/* Cart Panel */}
          {activeSidePanel === 'cart' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="p-4 bg-amber-600 text-white flex justify-between items-center">
                <div className="flex items-center">
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  <h2 className="text-lg font-semibold">Carrinho</h2>
                </div>
                <Button
                  variant="outline"
                  className="bg-amber-700 border-amber-500 text-white hover:bg-amber-800"
                  onClick={handleNewSale}
                >
                  Nova Venda (F4)
                </Button>
              </div>
              
              {/* Cart Items */}
              <div className="flex-1 overflow-auto p-4">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-gray-500">
                    <ShoppingCart className="h-12 w-12 mb-2" />
                    <p>Seu carrinho está vazio</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {cart.map((item) => (
                      <div key={item.productId} className="bg-gray-50 rounded-md p-3">
                        <div className="flex justify-between">
                          <div className="flex-1">
                            <h3 className="text-md font-medium text-gray-900">{item.productName}</h3>
                            <p className="text-sm text-gray-600">
                              {formatCurrency(item.unitPrice)} x {item.quantity} = {formatCurrency(item.total)}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <button
                              className="p-1 rounded-full text-gray-500 hover:bg-gray-200 hover:text-gray-700"
                              onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                            >
                              <Minus className="h-4 w-4" />
                            </button>
                            
                            <span className="text-gray-700 w-8 text-center">{item.quantity}</span>
                            
                            <button
                              className="p-1 rounded-full text-gray-500 hover:bg-gray-200 hover:text-gray-700"
                              onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                            >
                              <Plus className="h-4 w-4" />
                            </button>
                            
                            <button
                              className="p-1 rounded-full text-red-500 hover:bg-red-100"
                              onClick={() => removeItem(item.productId)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Customer Info (if selected) */}
              {selectedCustomer && (
                <div className="p-3 border-t border-gray-200 bg-blue-50">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center">
                        <Users className="h-4 w-4 text-blue-600 mr-1" />
                        <span className="text-sm font-medium text-blue-800">Cliente Selecionado</span>
                      </div>
                      <div className="mt-1">
                        <p className="text-sm">{selectedCustomer.name}</p>
                        <p className="text-xs text-gray-500">{selectedCustomer.phone || selectedCustomer.email}</p>
                      </div>
                    </div>
                    <button 
                      className="text-blue-600 hover:text-blue-800"
                      onClick={() => setSelectedCustomer(null)}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              )}
              
              {/* Cart Summary */}
              <div className="p-4 border-t border-gray-200">
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal:</span>
                    <span className="font-medium">{formatCurrency(getSubtotal())}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Impostos (9%):</span>
                    <span className="font-medium">{formatCurrency(getTax())}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-gray-200">
                    <span className="text-lg font-semibold">Total:</span>
                    <span className="text-lg font-semibold text-amber-600">{formatCurrency(getTotal())}</span>
                  </div>
                </div>
                
                <Button
                  className="w-full h-14 bg-green-600 hover:bg-green-700 text-white text-lg"
                  disabled={cart.length === 0 || cashierStatus === 'closed'}
                  onClick={() => {
                    setSelectedPaymentMethod('');
                    setCashReceived('');
                    setPaymentStep(1);
                    setIsPaymentModalOpen(true);
                  }}
                >
                  <CreditCard className="h-6 w-6 mr-2" />
                  Finalizar Venda (F8)
                </Button>
              </div>
            </div>
          )}
          
          {/* Customer Panel */}
          {activeSidePanel === 'customer' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="p-4 bg-blue-600 text-white">
                <h2 className="text-lg font-semibold flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  Clientes
                </h2>
              </div>
              
              <div className="p-4 border-b border-gray-200">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    placeholder="Pesquisar clientes..."
                  />
                </div>
              </div>
              
              <div className="flex-1 overflow-auto p-4">
                <div className="space-y-3">
                  {mockCustomers.map((customer) => (
                    <div 
                      key={customer.id}
                      className="bg-gray-50 rounded-md p-3 hover:bg-blue-50 cursor-pointer"
                      onClick={() => handleSelectCustomer(customer)}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-md font-medium text-gray-900">{customer.name}</h3>
                          <div className="text-sm text-gray-500 mt-1">
                            <div className="flex items-center">
                              {customer.type === 'business' ? (
                                <Building className="h-4 w-4 mr-1 text-gray-400" />
                              ) : (
                                <User className="h-4 w-4 mr-1 text-gray-400" />
                              )}
                              {customer.type === 'business' ? 'Empresa' : 'Pessoa Física'}
                            </div>
                          </div>
                        </div>
                        <span className="text-sm text-gray-500">
                          Cliente desde {new Date(customer.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="mt-2 flex text-sm text-gray-500 space-x-4">
                        {customer.phone && (
                          <span>{customer.phone}</span>
                        )}
                        {customer.email && (
                          <span>{customer.email}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="p-4 border-t border-gray-200">
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Novo Cliente
                </Button>
              </div>
            </div>
          )}
          
          {/* Products Panel (Last Sales) */}
          {activeSidePanel === 'products' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="p-4 bg-purple-600 text-white">
                <h2 className="text-lg font-semibold flex items-center">
                  <Package className="h-5 w-5 mr-2" />
                  Últimas Vendas
                </h2>
              </div>
              
              <div className="flex-1 overflow-auto">
                <div className="divide-y divide-gray-200">
                  {mockSales.map((sale, index) => (
                    <div key={index} className="p-4 hover:bg-gray-50">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center">
                            <span className="text-sm font-medium text-gray-900">Venda #{sale.id}</span>
                            <span className="ml-2 text-xs text-gray-500">
                              {new Date(sale.date).toLocaleString()}
                            </span>
                          </div>
                          
                          <div className="mt-1 space-y-1">
                            {sale.items.map((item, idx) => (
                              <div key={idx} className="flex text-sm">
                                <span className="text-gray-500 mr-1">{item.quantity}x</span>
                                <span className="text-gray-800">{item.productName}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        <div className="flex flex-col items-end">
                          <span className="font-semibold text-amber-600">{formatCurrency(sale.total)}</span>
                          <span className="text-xs text-gray-500 mt-1 capitalize">{sale.paymentMethod}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Status Panel */}
      <div className="bg-gray-800 text-white p-3 flex justify-between items-center text-sm">
        <div className="flex space-x-4">
          <div className="flex items-center">
            <CheckCircle className="h-4 w-4 text-green-400 mr-1" />
            <span>Sistema Online</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-4 w-4 text-blue-400 mr-1" />
            <span>{new Date().toLocaleTimeString()}</span>
          </div>
          <div className="flex items-center">
            <User className="h-4 w-4 text-amber-400 mr-1" />
            <span>Operador: Admin</span>
          </div>
        </div>
        
        <div className="flex space-x-4">
          <div className="flex items-center">
            <DollarSign className="h-4 w-4 text-green-400 mr-1" />
            <span>Saldo: {formatCurrency(cashierBalance)}</span>
          </div>
        </div>
      </div>
      
      {/* Payment Modal */}
      <Dialog open={isPaymentModalOpen} onOpenChange={setIsPaymentModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Finalizar Venda - {formatCurrency(getTotal())}</DialogTitle>
          </DialogHeader>
          
          {paymentStep === 1 && (
            <div className="grid grid-cols-2 gap-4 py-4">
              <Button
                className="h-20 flex flex-col items-center justify-center bg-green-100 text-green-800 hover:bg-green-200 border border-green-200"
                onClick={() => {
                  setSelectedPaymentMethod('cash');
                  setPaymentStep(2);
                }}
              >
                <Cash className="h-8 w-8 mb-2" />
                <span>Dinheiro</span>
              </Button>
              
              <Button
                className="h-20 flex flex-col items-center justify-center bg-blue-100 text-blue-800 hover:bg-blue-200 border border-blue-200"
                onClick={() => {
                  setSelectedPaymentMethod('credit');
                  setCardType('credit');
                  setPaymentStep(3);
                }}
              >
                <CardIcon className="h-8 w-8 mb-2" />
                <span>Cartão de Crédito</span>
              </Button>
              
              <Button
                className="h-20 flex flex-col items-center justify-center bg-purple-100 text-purple-800 hover:bg-purple-200 border border-purple-200"
                onClick={() => {
                  setSelectedPaymentMethod('debit');
                  setCardType('debit');
                  setPaymentStep(3);
                }}
              >
                <CardIcon className="h-8 w-8 mb-2" />
                <span>Cartão de Débito</span>
              </Button>
              
              <Button
                className="h-20 flex flex-col items-center justify-center bg-amber-100 text-amber-800 hover:bg-amber-200 border border-amber-200"
                onClick={() => {
                  setSelectedPaymentMethod('pix');
                  setPaymentStep(4);
                }}
              >
                <File className="h-8 w-8 mb-2" />
                <span>PIX</span>
              </Button>
            </div>
          )}
          
          {/* Cash payment */}
          {paymentStep === 2 && (
            <div className="space-y-4 py-4">
              <div>
                <label htmlFor="cashReceived" className="block text-sm font-medium text-gray-700 mb-1">
                  Valor Recebido
                </label>
                <div className="relative mt-1">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-gray-500 sm:text-sm">R$</span>
                  </div>
                  <input
                    type="number"
                    id="cashReceived"
                    className="focus:ring-amber-500 focus:border-amber-500 block w-full pl-8 pr-12 sm:text-sm border-gray-300 rounded-md py-3 text-lg"
                    placeholder="0.00"
                    value={cashReceived}
                    onChange={(e) => setCashReceived(e.target.value)}
                    autoFocus
                  />
                </div>
              </div>
              
              {cashReceived && parseFloat(cashReceived) >= getTotal() && (
                <div className="bg-green-50 p-3 rounded-md">
                  <div className="flex justify-between items-center text-green-800">
                    <span className="font-medium">Troco:</span>
                    <span className="text-lg font-semibold">
                      {formatCurrency(parseFloat(cashReceived) - getTotal())}
                    </span>
                  </div>
                </div>
              )}
              
              <div className="flex justify-between pt-4">
                <Button
                  variant="outline"
                  onClick={() => setPaymentStep(1)}
                >
                  Voltar
                </Button>
                
                <Button
                  onClick={handlePayment}
                  disabled={!cashReceived || parseFloat(cashReceived) < getTotal()}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Finalizar Pagamento
                </Button>
              </div>
            </div>
          )}
          
          {/* Card payment */}
          {paymentStep === 3 && (
            <div className="space-y-4 py-4">
              <div className="bg-blue-50 p-4 rounded-md">
                <h3 className="text-blue-800 font-medium mb-2">
                  {cardType === 'credit' ? 'Pagamento com Cartão de Crédito' : 'Pagamento com Cartão de Débito'}
                </h3>
                <p className="text-blue-600 text-sm">
                  Valor a pagar: {formatCurrency(getTotal())}
                </p>
                
                {cardType === 'credit' && (
                  <div className="mt-3">
                    <label htmlFor="installments" className="block text-sm font-medium text-gray-700 mb-1">
                      Número de Parcelas
                    </label>
                    <select
                      id="installments"
                      className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      value={installments}
                      onChange={(e) => setInstallments(Number(e.target.value))}
                    >
                      <option value="1">À vista</option>
                      <option value="2">2x sem juros</option>
                      <option value="3">3x sem juros</option>
                      <option value="4">4x sem juros</option>
                      <option value="5">5x sem juros</option>
                      <option value="6">6x sem juros</option>
                    </select>
                    
                    {installments > 1 && (
                      <div className="mt-2 text-sm text-gray-700">
                        {installments}x de {formatCurrency(getTotal() / installments)}
                      </div>
                    )}
                  </div>
                )}
                
                <div className="mt-3 p-3 rounded-md border border-blue-200 bg-white">
                  <div className="text-center text-sm text-blue-800">
                    <p className="mb-1 font-medium">Instruções:</p>
                    <p>1. Insira ou aproxime o cartão na máquina</p>
                    <p>2. Aguarde o processamento</p>
                    <p>3. Digite a senha se solicitado</p>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-between pt-4">
                <Button
                  variant="outline"
                  onClick={() => setPaymentStep(1)}
                >
                  Voltar
                </Button>
                
                <Button
                  onClick={handlePayment}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Processar Pagamento
                </Button>
              </div>
            </div>
          )}
          
          {/* PIX payment */}
          {paymentStep === 4 && (
            <div className="space-y-4 py-4">
              <div className="bg-amber-50 p-4 rounded-md">
                <h3 className="text-amber-800 font-medium mb-2">
                  Pagamento com PIX
                </h3>
                <p className="text-amber-600 text-sm">
                  Valor a pagar: {formatCurrency(getTotal())}
                </p>
                
                <div className="mt-3 bg-white p-3 rounded-md border border-amber-200 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-48 h-48 mx-auto bg-gray-200 flex items-center justify-center border">
                      <File className="h-12 w-12 text-gray-400" />
                    </div>
                    <p className="mt-2 text-sm text-gray-500">QR Code PIX</p>
                    <p className="mt-1 text-xs text-gray-500">Escaneie com seu aplicativo de banco</p>
                  </div>
                </div>
                
                <div className="mt-3 p-3 bg-white rounded-md border border-amber-200">
                  <div className="text-center">
                    <p className="text-sm font-medium text-gray-800 mb-1">PIX Copia e Cola:</p>
                    <p className="text-xs break-all bg-gray-100 p-2 rounded-md border border-gray-200">
                      00020126580014br.gov.bcb.pix0136e4da9311-8a63-4a54-9283-3e35a4f3780b0212Pagamento PDV5204000053039865802BR5913ControlAI PDV6009SAO PAULO62070503***6304E2CA
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-between pt-4">
                <Button
                  variant="outline"
                  onClick={() => setPaymentStep(1)}
                >
                  Voltar
                </Button>
                
                <Button
                  onClick={handlePayment}
                  className="bg-amber-600 hover:bg-amber-700"
                >
                  Confirmar Pagamento
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      
      {/* NFCe Modal */}
      <Dialog open={isNFCeModalOpen} onOpenChange={setIsNFCeModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Emitir Nota Fiscal de Consumidor Eletrônica</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="bg-amber-50 p-4 rounded-md border border-amber-200">
              <h3 className="text-amber-800 font-medium flex items-center">
                <FileDigit className="h-5 w-5 mr-2" />
                Emissão de NFCe
              </h3>
              <p className="mt-2 text-sm text-amber-600">
                A NFCe será emitida para a venda atual. Certifique-se de que os produtos e quantidades estão corretos.
              </p>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="customerDocument">CPF/CNPJ do Cliente (Opcional)</Label>
                <Input
                  id="customerDocument"
                  placeholder="Ex: 123.456.789-00"
                />
              </div>
              
              <div>
                <Label htmlFor="customerName">Nome do Cliente (Opcional)</Label>
                <Input
                  id="customerName"
                  placeholder="Ex: João da Silva"
                />
              </div>
              
              <div className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    id="sendEmail"
                    name="sendEmail"
                    type="checkbox"
                    className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                  />
                </div>
                <div className="ml-3 text-sm">
                  <Label htmlFor="sendEmail">Enviar NFCe por e-mail</Label>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsNFCeModalOpen(false)}
            >
              Cancelar
            </Button>
            
            <Button
              onClick={handleNFCeEmission}
              className="bg-amber-600 hover:bg-amber-700"
            >
              Emitir NFCe
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Cashier Modal */}
      <Dialog open={isCashierModalOpen} onOpenChange={setIsCashierModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {cashierStatus === 'open' ? 'Fechar Caixa' : 'Abrir Caixa'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="py-4 space-y-4">
            {cashierStatus === 'open' ? (
              <div className="space-y-4">
                <div className="bg-gray-50 rounded-md p-4">
                  <h3 className="text-lg font-medium text-gray-900 mb-3">Resumo do Caixa</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Saldo Inicial</p>
                      <p className="text-lg font-semibold text-gray-900">R$ 500,00</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Saldo Atual</p>
                      <p className="text-lg font-semibold text-green-600">{formatCurrency(cashierBalance)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Entradas</p>
                      <p className="text-md font-medium text-green-600">+R$ 645,75</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Saídas</p>
                      <p className="text-md font-medium text-red-600">-R$ 145,75</p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="closingNotes">Observações</Label>
                  <textarea
                    id="closingNotes"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-amber-500 focus:ring-amber-500"
                    rows={3}
                  />
                </div>
                
                <div className="flex items-start">
                  <div className="flex items-center h-5">
                    <input
                      id="printReport"
                      name="printReport"
                      type="checkbox"
                      className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                      defaultChecked
                    />
                  </div>
                  <div className="ml-3 text-sm">
                    <Label htmlFor="printReport">Imprimir relatório de fechamento</Label>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="initialBalance">Saldo Inicial</Label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 sm:text-sm">R$</span>
                    </div>
                    <input
                      type="number"
                      id="initialBalance"
                      className="focus:ring-amber-500 focus:border-amber-500 block w-full pl-10 pr-12 sm:text-sm border-gray-300 rounded-md"
                      placeholder="0.00"
                      defaultValue="500.00"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="openingNotes">Observações</Label>
                  <textarea
                    id="openingNotes"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-amber-500 focus:ring-amber-500"
                    rows={3}
                  />
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsCashierModalOpen(false)}
            >
              Cancelar
            </Button>
            
            <Button
              className={cashierStatus === 'open' ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}
              onClick={cashierStatus === 'open' ? handleCloseCashier : handleOpenCashier}
            >
              {cashierStatus === 'open' ? 'Fechar Caixa' : 'Abrir Caixa'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Cash Withdrawal Modal */}
      <Dialog open={isWithdrawalModalOpen} onOpenChange={setIsWithdrawalModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Retirada de Dinheiro (Sangria)</DialogTitle>
          </DialogHeader>
          
          <div className="py-4 space-y-4">
            <div className="bg-blue-50 p-4 rounded-md">
              <p className="text-sm text-blue-800">
                Saldo atual do caixa: <span className="font-medium">{formatCurrency(cashierBalance)}</span>
              </p>
            </div>
            
            <div>
              <Label htmlFor="withdrawalAmount">Valor da Retirada</Label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">R$</span>
                </div>
                <input
                  type="number"
                  id="withdrawalAmount"
                  className="focus:ring-red-500 focus:border-red-500 block w-full pl-10 pr-12 sm:text-sm border-gray-300 rounded-md"
                  placeholder="0.00"
                  value={operationAmount}
                  onChange={(e) => setOperationAmount(e.target.value)}
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="withdrawalReason" className="block text-sm font-medium text-gray-700">
                Motivo da Retirada
              </Label>
              <select
                id="withdrawalReason"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm rounded-md"
                value={operationReason}
                onChange={(e) => setOperationReason(e.target.value)}
              >
                <option value="">Selecione um motivo</option>
                <option value="bankDeposit">Depósito em Banco</option>
                <option value="changeSupply">Suprimento de Troco</option>
                <option value="expenses">Despesas Diversas</option>
                <option value="other">Outros</option>
              </select>
            </div>
            
            {operationReason === 'other' && (
              <div>
                <Label htmlFor="withdrawalNotes">Especifique o Motivo</Label>
                <textarea
                  id="withdrawalNotes"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                  rows={2}
                />
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsWithdrawalModalOpen(false)}
            >
              Cancelar
            </Button>
            
            <Button
              className="bg-red-600 hover:bg-red-700"
              onClick={handleCashWithdrawal}
            >
              Confirmar Retirada
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Cash Deposit Modal */}
      <Dialog open={isDepositModalOpen} onOpenChange={setIsDepositModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Entrada de Dinheiro (Suprimento)</DialogTitle>
          </DialogHeader>
          
          <div className="py-4 space-y-4">
            <div className="bg-blue-50 p-4 rounded-md">
              <p className="text-sm text-blue-800">
                Saldo atual do caixa: <span className="font-medium">{formatCurrency(cashierBalance)}</span>
              </p>
            </div>
            
            <div>
              <Label htmlFor="depositAmount">Valor do Suprimento</Label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">R$</span>
                </div>
                <input
                  type="number"
                  id="depositAmount"
                  className="focus:ring-green-500 focus:border-green-500 block w-full pl-10 pr-12 sm:text-sm border-gray-300 rounded-md"
                  placeholder="0.00"
                  value={operationAmount}
                  onChange={(e) => setOperationAmount(e.target.value)}
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="depositReason" className="block text-sm font-medium text-gray-700">
                Motivo do Suprimento
              </Label>
              <select
                id="depositReason"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm rounded-md"
                value={operationReason}
                onChange={(e) => setOperationReason(e.target.value)}
              >
                <option value="">Selecione um motivo</option>
                <option value="initialMoney">Dinheiro Inicial</option>
                <option value="changeSupply">Suprimento de Troco</option>
                <option value="cashCollection">Coleta de Valores</option>
                <option value="other">Outros</option>
              </select>
            </div>
            
            {operationReason === 'other' && (
              <div>
                <Label htmlFor="depositNotes">Especifique o Motivo</Label>
                <textarea
                  id="depositNotes"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                  rows={2}
                />
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDepositModalOpen(false)}
            >
              Cancelar
            </Button>
            
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={handleCashDeposit}
            >
              Confirmar Suprimento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Cancel Operation Modal */}
      <Dialog open={isCancelModalOpen} onOpenChange={setIsCancelModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancelamento de Operação</DialogTitle>
          </DialogHeader>
          
          <div className="py-4 space-y-4">
            <div className="bg-red-50 p-4 rounded-md">
              <div className="flex">
                <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                <div>
                  <h3 className="text-sm font-medium text-red-800">Atenção!</h3>
                  <p className="text-sm text-red-700 mt-1">
                    O cancelamento de operações deve ser realizado apenas em casos específicos 
                    e será registrado para auditoria.
                  </p>
                </div>
              </div>
            </div>
            
            <div>
              <Label htmlFor="cancelType" className="block text-sm font-medium text-gray-700">
                Tipo de Cancelamento
              </Label>
              <select
                id="cancelType"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-red-500 focus:border-red-500 sm:text-sm rounded-md"
              >
                <option value="">Selecione uma opção</option>
                <option value="currentSale">Venda Atual</option>
                <option value="lastSale">Última Venda</option>
                <option value="specificSale">Venda Específica</option>
                <option value="fiscalDocument">Documento Fiscal</option>
              </select>
            </div>
            
            <div>
              <Label htmlFor="cancelReason" className="block text-sm font-medium text-gray-700">
                Motivo do Cancelamento
              </Label>
              <textarea
                id="cancelReason"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                rows={3}
                placeholder="Descreva detalhadamente o motivo do cancelamento"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="cancelAuthCode" className="block text-sm font-medium text-gray-700">
                Código de Autorização
              </Label>
              <input
                type="password"
                id="cancelAuthCode"
                className="mt-1 focus:ring-red-500 focus:border-red-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                placeholder="Código de autorização do gerente"
                required
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsCancelModalOpen(false)}
            >
              Voltar
            </Button>
            
            <Button
              className="bg-red-600 hover:bg-red-700"
              onClick={() => {
                toast.error('Operação cancelada! Este recurso requer autorização do gerente.');
                setIsCancelModalOpen(false);
              }}
            >
              Confirmar Cancelamento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Settings Modal */}
      <Dialog open={isSettingsModalOpen} onOpenChange={setIsSettingsModalOpen}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle>Configurações do PDV</DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <div className="flex border-b border-gray-200">
              <button 
                className={`px-4 py-2 border-b-2 font-medium text-sm ${
                  settingsTab === 'general' 
                    ? 'border-amber-500 text-amber-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
                onClick={() => setSettingsTab('general')}
              >
                Geral
              </button>
              <button 
                className={`px-4 py-2 border-b-2 font-medium text-sm ${
                  settingsTab === 'fiscal' 
                    ? 'border-amber-500 text-amber-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
                onClick={() => setSettingsTab('fiscal')}
              >
                Fiscal
              </button>
              <button 
                className={`px-4 py-2 border-b-2 font-medium text-sm ${
                  settingsTab === 'interface' 
                    ? 'border-amber-500 text-amber-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
                onClick={() => setSettingsTab('interface')}
              >
                Interface
              </button>
              <button 
                className={`px-4 py-2 border-b-2 font-medium text-sm ${
                  settingsTab === 'users' 
                    ? 'border-amber-500 text-amber-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
                onClick={() => setSettingsTab('users')}
              >
                Usuários
              </button>
            </div>
            
            <div className="mt-4">
              {settingsTab === 'general' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-3">Configurações Gerais</h3>
                      
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="pdvName">Nome do PDV</Label>
                          <Input id="pdvName" defaultValue="PDV Principal" />
                        </div>
                        
                        <div>
                          <Label htmlFor="printerType">Impressora</Label>
                          <select
                            id="printerType"
                            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                          >
                            <option value="thermal">Impressora Térmica</option>
                            <option value="matrix">Impressora Matricial</option>
                            <option value="laser">Impressora Laser</option>
                          </select>
                        </div>
                        
                        <div>
                          <Label htmlFor="printReceipt">Impressão do Comprovante</Label>
                          <select
                            id="printReceipt"
                            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                          >
                            <option value="always">Sempre Imprimir</option>
                            <option value="ask">Perguntar</option>
                            <option value="never">Não Imprimir</option>
                          </select>
                        </div>
                        
                        <div className="flex items-center">
                          <input
                            id="autoOpenDrawer"
                            type="checkbox"
                            className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                            defaultChecked
                          />
                          <Label htmlFor="autoOpenDrawer" className="ml-2">
                            Abrir gaveta automaticamente após venda
                          </Label>
                        </div>
                        
                        <div className="flex items-center">
                          <input
                            id="showCustomerPanel"
                            type="checkbox"
                            className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                            defaultChecked
                          />
                          <Label htmlFor="showCustomerPanel" className="ml-2">
                            Mostrar painel do cliente
                          </Label>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-3">Comportamento de Vendas</h3>
                      
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="defaultPaymentMethod">Método de Pagamento Padrão</Label>
                          <select
                            id="defaultPaymentMethod"
                            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                          >
                            <option value="">Selecionar Sempre</option>
                            <option value="cash">Dinheiro</option>
                            <option value="credit">Cartão de Crédito</option>
                            <option value="debit">Cartão de Débito</option>
                            <option value="pix">PIX</option>
                          </select>
                        </div>
                        
                        <div>
                          <Label htmlFor="defaultDiscount">Desconto Padrão (%)</Label>
                          <Input id="defaultDiscount" type="number" min="0" max="100" defaultValue="0" />
                        </div>
                        
                        <div>
                          <Label htmlFor="barcodeTimeout">Timeout de Leitura de Código de Barras (ms)</Label>
                          <Input id="barcodeTimeout" type="number" min="100" step="100" defaultValue="1500" />
                        </div>
                        
                        <div className="flex items-center">
                          <input
                            id="allowPriceOverride"
                            type="checkbox"
                            className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                          />
                          <Label htmlFor="allowPriceOverride" className="ml-2">
                            Permitir alteração de preço
                          </Label>
                        </div>
                        
                        <div className="flex items-center">
                          <input
                            id="requireCustomerForSale"
                            type="checkbox"
                            className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                          />
                          <Label htmlFor="requireCustomerForSale" className="ml-2">
                            Exigir cliente para finalizar venda
                          </Label>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900 mb-3">Companhia</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="companyName">Nome da Empresa</Label>
                        <Input 
                          id="companyName" 
                          value={companyName}
                          onChange={(e) => setCompanyName(e.target.value)}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="companyLogo">Logo da Empresa</Label>
                        <div className="mt-1 flex items-center">
                          {companyLogo ? (
                            <div className="mr-3 h-16 w-32 border border-gray-300 rounded overflow-hidden bg-white p-1 flex items-center justify-center">
                              <img
                                src={companyLogo}
                                alt="Logo"
                                className="max-h-full max-w-full object-contain"
                              />
                            </div>
                          ) : (
                            <div className="mr-3 h-16 w-32 border border-gray-300 rounded bg-gray-100 flex items-center justify-center text-xs text-gray-400">
                              Sem logo
                            </div>
                          )}
                          
                          <label htmlFor="logo-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-amber-600 hover:text-amber-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-amber-500">
                            <span className="p-2 border border-amber-300 rounded-md">Selecionar logo</span>
                            <input 
                              id="logo-upload" 
                              name="logo-upload" 
                              type="file" 
                              className="sr-only" 
                              accept="image/png,image/jpeg"
                              onChange={handleLogoUpload}
                            />
                          </label>
                          
                          {companyLogo && (
                            <button
                              type="button"
                              className="ml-2 p-1 rounded-full text-red-500 hover:bg-red-100"
                              onClick={() => {
                                setCompanyLogo(null);
                                localStorage.removeItem('companyLogo');
                                toast.success('Logo removido com sucesso!');
                              }}
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          )}
                        </div>
                        <p className="mt-2 text-xs text-gray-500">
                          Dimensões recomendadas: 200x60px. Formatos: PNG, JPG (máx. 2MB)
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {settingsTab === 'fiscal' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-3">Configurações Fiscais</h3>
                      
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="fiscalEnvironment">Ambiente Fiscal</Label>
                          <select
                            id="fiscalEnvironment"
                            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                          >
                            <option value="test">Homologação (Testes)</option>
                            <option value="production">Produção</option>
                          </select>
                        </div>
                        
                        <div>
                          <Label htmlFor="fiscalProvider">Provedor Fiscal</Label>
                          <select
                            id="fiscalProvider"
                            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                          >
                            <option value="default">Integração Padrão</option>
                            <option value="nfce_tech">NFCe Tech</option>
                            <option value="fiscal_cloud">Fiscal Cloud</option>
                            <option value="sefaz_direct">Sefaz Direto</option>
                          </select>
                        </div>
                        
                        <div>
                          <Label htmlFor="defaultDocumentType">Documento Fiscal Padrão</Label>
                          <select
                            id="defaultDocumentType"
                            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                          >
                            <option value="nfce">NFCe - Nota Fiscal de Consumidor Eletrônica</option>
                            <option value="nfe">NFe - Nota Fiscal Eletrônica</option>
                            <option value="none">Nenhum (Apenas Cupom Não Fiscal)</option>
                          </select>
                        </div>
                        
                        <div className="flex items-center">
                          <input
                            id="autoGenerateFiscal"
                            type="checkbox"
                            className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                            defaultChecked
                          />
                          <Label htmlFor="autoGenerateFiscal" className="ml-2">
                            Gerar documento fiscal automaticamente após venda
                          </Label>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-3">Tributação</h3>
                      
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="taxRegime">Regime Tributário</Label>
                          <select
                            id="taxRegime"
                            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                          >
                            <option value="simples">Simples Nacional</option>
                            <option value="real">Lucro Real</option>
                            <option value="presumido">Lucro Presumido</option>
                          </select>
                        </div>
                        
                        <div>
                          <Label htmlFor="defaultCFOP">CFOP Padrão para Vendas</Label>
                          <Input id="defaultCFOP" defaultValue="5102" />
                          <p className="mt-1 text-xs text-gray-500">
                            CFOP para vendas dentro do estado. Ex: 5102 - Venda de mercadoria adquirida ou recebida de terceiros
                          </p>
                        </div>
                        
                        <div>
                          <Label htmlFor="defaultICMS">Alíquota Padrão de ICMS (%)</Label>
                          <Input id="defaultICMS" type="number" min="0" max="100" step="0.01" defaultValue="18" />
                        </div>
                        
                        <div>
                          <Label htmlFor="defaultPIS">Alíquota Padrão de PIS (%)</Label>
                          <Input id="defaultPIS" type="number" min="0" max="100" step="0.01" defaultValue="0.65" />
                        </div>
                        
                        <div>
                          <Label htmlFor="defaultCOFINS">Alíquota Padrão de COFINS (%)</Label>
                          <Input id="defaultCOFINS" type="number" min="0" max="100" step="0.01" defaultValue="3" />
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900 mb-3">Certificado Digital</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="certificateType">Tipo de Certificado</Label>
                        <select
                          id="certificateType"
                          className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                        >
                          <option value="a1">A1</option>
                          <option value="a3">A3</option>
                        </select>
                      </div>
                      
                      <div>
                        <Label htmlFor="certificateFile">Arquivo do Certificado</Label>
                        <div className="mt-1 flex">
                          <input
                            id="certificateFile"
                            type="text"
                            className="focus:ring-amber-500 focus:border-amber-500 flex-1 block w-full rounded-none rounded-l-md sm:text-sm border-gray-300"
                            placeholder="Nenhum arquivo selecionado"
                            readOnly
                          />
                          <button
                            type="button"
                            className="inline-flex items-center px-3 py-2 border border-l-0 border-gray-300 bg-gray-50 text-gray-700 text-sm rounded-r-md hover:bg-gray-100"
                          >
                            Selecionar
                          </button>
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="certificatePassword">Senha do Certificado</Label>
                        <div className="mt-1 relative rounded-md shadow-sm">
                          <input
                            type="password"
                            id="certificatePassword"
                            className="focus:ring-amber-500 focus:border-amber-500 block w-full pr-10 sm:text-sm border-gray-300 rounded-md"
                            placeholder="Senha do certificado"
                          />
                          <div className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer">
                            <Eye className="h-5 w-5 text-gray-400" />
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="certificateExpiration">Válido até</Label>
                        <Input 
                          id="certificateExpiration" 
                          type="date" 
                          defaultValue="2025-12-31" 
                          disabled 
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {settingsTab === 'interface' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-3">Personalização de Interface</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="theme">Tema</Label>
                        <select
                          id="theme"
                          className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                        >
                          <option value="light">Claro</option>
                          <option value="dark">Escuro</option>
                          <option value="system">Sistema</option>
                        </select>
                      </div>
                      
                      <div>
                        <Label htmlFor="fontFamily">Família de Fonte</Label>
                        <select
                          id="fontFamily"
                          className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                        >
                          <option value="inter">Inter</option>
                          <option value="roboto">Roboto</option>
                          <option value="opensans">Open Sans</option>
                          <option value="system">Fonte do Sistema</option>
                        </select>
                      </div>
                      
                      <div>
                        <Label htmlFor="fontSize">Tamanho da Fonte</Label>
                        <select
                          id="fontSize"
                          className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                        >
                          <option value="small">Pequeno</option>
                          <option value="medium" selected>Médio</option>
                          <option value="large">Grande</option>
                        </select>
                      </div>
                      
                      <div>
                        <Label htmlFor="primaryColor">Cor Primária</Label>
                        <div className="mt-1 flex">
                          <input
                            type="color"
                            id="primaryColor"
                            defaultValue="#d97706"
                            className="h-10 w-10 border-0 rounded p-0"
                          />
                          <Input 
                            className="flex-1 ml-2" 
                            id="primaryColorHex" 
                            defaultValue="#d97706" 
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900 mb-3">Layout e Organização</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="productLayout">Layout de Produtos</Label>
                        <select
                          id="productLayout"
                          className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                        >
                          <option value="grid">Grade</option>
                          <option value="list">Lista</option>
                        </select>
                      </div>
                      
                      <div>
                        <Label htmlFor="productView">Visualização de Produtos</Label>
                        <select
                          id="productView"
                          className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                        >
                          <option value="all">Todos os Produtos</option>
                          <option value="categories">Organizar por Categorias</option>
                        </select>
                      </div>
                      
                      <div>
                        <Label>Mostrar Painel Lateral</Label>
                        <div className="mt-2 space-y-2">
                          <div className="flex items-center">
                            <input
                              id="showCart"
                              name="showCart"
                              type="checkbox"
                              className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                              defaultChecked
                            />
                            <label htmlFor="showCart" className="ml-2 block text-sm text-gray-700">
                              Painel de Carrinho
                            </label>
                          </div>
                          
                          <div className="flex items-center">
                            <input
                              id="showCustomer"
                              name="showCustomer"
                              type="checkbox"
                              className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                              defaultChecked
                            />
                            <label htmlFor="showCustomer" className="ml-2 block text-sm text-gray-700">
                              Painel de Cliente
                            </label>
                          </div>
                          
                          <div className="flex items-center">
                            <input
                              id="showProducts"
                              name="showProducts"
                              type="checkbox"
                              className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                              defaultChecked
                            />
                            <label htmlFor="showProducts" className="ml-2 block text-sm text-gray-700">
                              Painel de Últimas Vendas
                            </label>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="buttonSize">Tamanho dos Botões</Label>
                        <select
                          id="buttonSize"
                          className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                        >
                          <option value="small">Pequeno</option>
                          <option value="medium" selected>Médio</option>
                          <option value="large">Grande</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {settingsTab === 'users' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-3">Permissões e Usuários</h3>
                    
                    <div className="mt-4 border border-gray-200 rounded-md shadow-sm overflow-hidden">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Usuário
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Perfil
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Último Acesso
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                            <th scope="col" className="relative px-6 py-3">
                              <span className="sr-only">Ações</span>
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="h-8 w-8 bg-amber-100 text-amber-800 rounded-full flex items-center justify-center">
                                  <User className="h-5 w-5" />
                                </div>
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-gray-900">Admin User</div>
                                  <div className="text-sm text-gray-500">admin@bakery.com</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">Administrador</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-500">Hoje, 10:24</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                Ativo
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <a href="#" className="text-amber-600 hover:text-amber-900">Editar</a>
                            </td>
                          </tr>
                          
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="h-8 w-8 bg-green-100 text-green-800 rounded-full flex items-center justify-center">
                                  <User className="h-5 w-5" />
                                </div>
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-gray-900">Cashier User</div>
                                  <div className="text-sm text-gray-500">cashier@bakery.com</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">Caixa</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-500">Ontem, 19:45</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                Ativo
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <a href="#" className="text-amber-600 hover:text-amber-900">Editar</a>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    
                    <div className="mt-4">
                      <Button className="bg-amber-600 hover:bg-amber-700">
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar Usuário
                      </Button>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900 mb-3">Permissões do PDV</h3>
                    
                    <div className="mt-4 border border-gray-200 rounded-md shadow-sm overflow-hidden">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Recurso
                            </th>
                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Administrador
                            </th>
                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Gerente
                            </th>
                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Caixa
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              Abertura/Fechamento de Caixa
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <XCircle className="h-5 w-5 text-red-500 mx-auto" />
                            </td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              Sangria/Suprimento
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              Cancelamento de Venda
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <XCircle className="h-5 w-5 text-red-500 mx-auto" />
                            </td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              Emissão de Documentos Fiscais
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                          </tr>
                          <tr>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              Configurações
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <XCircle className="h-5 w-5 text-red-500 mx-auto" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <XCircle className="h-5 w-5 text-red-500 mx-auto" />
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsSettingsModalOpen(false)}
            >
              Cancelar
            </Button>
            
            <Button
              onClick={() => {
                toast.success("Configurações salvas com sucesso!");
                setIsSettingsModalOpen(false);
              }}
              className="bg-amber-600 hover:bg-amber-700"
            >
              Salvar Configurações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* TEF Modal */}
      <Dialog open={isTEFModalOpen} onOpenChange={setIsTEFModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Configuração e Operação TEF</DialogTitle>
          </DialogHeader>
          
          <div className="py-4 space-y-5">
            <div className="bg-gray-50 p-4 rounded-md">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">Status do TEF</h3>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  tefStatus === 'connected' 
                    ? 'bg-green-100 text-green-800' 
                    : tefStatus === 'processing'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-red-100 text-red-800'
                }`}>
                  {tefStatus === 'connected' 
                    ? 'Conectado' 
                    : tefStatus === 'processing'
                      ? 'Processando'
                      : 'Desconectado'}
                </span>
              </div>
              
              <div className="mt-3">
                <p className="text-sm text-gray-500">
                  O TEF (Transferência Eletrônica de Fundos) permite processar pagamentos com cartões de crédito e débito.
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="tefProvider">Provedor TEF</Label>
                <select
                  id="tefProvider"
                  className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                  value={tefProvider}
                  onChange={(e) => setTefProvider(e.target.value)}
                >
                  <option value="stone">Stone</option>
                  <option value="cielo">Cielo</option>
                  <option value="getnet">Getnet</option>
                  <option value="rede">Rede</option>
                  <option value="safra">Safra</option>
                </select>
              </div>
              
              <div>
                <Label htmlFor="tefPort">Porta de Comunicação</Label>
                <select
                  id="tefPort"
                  className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                >
                  <option value="COM1">COM1</option>
                  <option value="COM2">COM2</option>
                  <option value="COM3">COM3</option>
                  <option value="COM4">COM4</option>
                  <option value="IP">TCP/IP</option>
                </select>
              </div>
              
              <div>
                <Label htmlFor="tefTimeout">Timeout (segundos)</Label>
                <Input id="tefTimeout" type="number" min="5" max="120" defaultValue="30" />
              </div>
              
              <div>
                <Label htmlFor="tefRetryCount">Número de Tentativas</Label>
                <Input id="tefRetryCount" type="number" min="1" max="10" defaultValue="3" />
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-3">Bandeiras Aceitas</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center">
                  <input
                    id="acceptVisa"
                    name="acceptVisa"
                    type="checkbox"
                    className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                    defaultChecked
                  />
                  <label htmlFor="acceptVisa" className="ml-2 block text-sm text-gray-700">
                    Visa
                  </label>
                </div>
                
                <div className="flex items-center">
                  <input
                    id="acceptMastercard"
                    name="acceptMastercard"
                    type="checkbox"
                    className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                    defaultChecked
                  />
                  <label htmlFor="acceptMastercard" className="ml-2 block text-sm text-gray-700">
                    Mastercard
                  </label>
                </div>
                
                <div className="flex items-center">
                  <input
                    id="acceptElo"
                    name="acceptElo"
                    type="checkbox"
                    className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                    defaultChecked
                  />
                  <label htmlFor="acceptElo" className="ml-2 block text-sm text-gray-700">
                    Elo
                  </label>
                </div>
                
                <div className="flex items-center">
                  <input
                    id="acceptAmex"
                    name="acceptAmex"
                    type="checkbox"
                    className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                    defaultChecked
                  />
                  <label htmlFor="acceptAmex" className="ml-2 block text-sm text-gray-700">
                    American Express
                  </label>
                </div>
                
                <div className="flex items-center">
                  <input
                    id="acceptHipercard"
                    name="acceptHipercard"
                    type="checkbox"
                    className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                    defaultChecked
                  />
                  <label htmlFor="acceptHipercard" className="ml-2 block text-sm text-gray-700">
                    Hipercard
                  </label>
                </div>
                
                <div className="flex items-center">
                  <input
                    id="acceptDiners"
                    name="acceptDiners"
                    type="checkbox"
                    className="focus:ring-amber-500 h-4 w-4 text-amber-600 border-gray-300 rounded"
                  />
                  <label htmlFor="acceptDiners" className="ml-2 block text-sm text-gray-700">
                    Diners Club
                  </label>
                </div>
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-3">Ações</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <Button 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={handleTestTEF}
                  disabled={tefStatus === 'processing'}
                >
                  {tefStatus === 'processing' ? (
                    <>
                      <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
                      Testando...
                    </>
                  ) : (
                    <>
                      <Activity className="h-5 w-5 mr-2" />
                      Testar Comunicação
                    </>
                  )}
                </Button>
                
                <Button 
                  variant="outline"
                >
                  <FileText className="h-5 w-5 mr-2" />
                  Ver Logs
                </Button>
                
                <Button variant="outline">
                  <Printer className="h-5 w-5 mr-2" />
                  Imprimir Via
                </Button>
                
                <Button variant="outline" className="text-red-600 border-red-200 hover:bg-red-50">
                  <XCircle className="h-5 w-5 mr-2" />
                  Cancelar Última
                </Button>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              onClick={() => setIsTEFModalOpen(false)}
              className="bg-amber-600 hover:bg-amber-700"
            >
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Product Search Modal */}
      <Dialog open={isProductSearchModalOpen} onOpenChange={setIsProductSearchModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Busca de Produtos</DialogTitle>
          </DialogHeader>
          
          <div className="py-4 space-y-4">
            <div className="flex space-x-2">
              <div className="relative flex-1">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                  placeholder="Código, nome ou descrição do produto"
                  autoFocus
                />
              </div>
              
              <Button>
                <Search className="h-4 w-4 mr-1" />
                Buscar
              </Button>
            </div>
            
            <div className="border border-gray-200 rounded-md shadow-sm overflow-hidden max-h-96 overflow-y-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Código
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Produto
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Preço
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Estoque
                    </th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Ações</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {mockProducts.slice(0, 5).map((product) => (
                    <tr key={product.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {product.internalCode || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{product.name}</div>
                        <div className="text-sm text-gray-500">{product.category}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatCurrency(product.price)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                          Disponível
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <Button 
                          size="sm"
                          className="bg-amber-600 hover:bg-amber-700"
                          onClick={() => {
                            addToCart(product);
                            setIsProductSearchModalOpen(false);
                          }}
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          Adicionar
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline"
              onClick={() => setIsProductSearchModalOpen(false)}
            >
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

function Building({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <rect width="16" height="20" x="4" y="2" rx="2" ry="2" />
      <path d="M9 22v-4h6v4" />
      <path d="M8 6h.01" />
      <path d="M16 6h.01" />
      <path d="M12 6h.01" />
      <path d="M12 10h.01" />
      <path d="M12 14h.01" />
      <path d="M16 10h.01" />
      <path d="M16 14h.01" />
      <path d="M8 10h.01" />
      <path d="M8 14h.01" />
    </svg>
  );
}