import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Calculator, FileText, Database, FileBarChart, FileDigit, Building2, Users, Clock, ChevronRight, AlertTriangle, CheckCircle, Info, Calendar } from 'lucide-react';
import { getCertificateStatus, getTaxObligationSummary, getDocumentSummary } from '../../data/mockAccountingData';

export const AccountingModule: React.FC = () => {
  const navigate = useNavigate();
  const companyId = '1'; // Default company for demo
  
  const certificateStatus = getCertificateStatus(companyId);
  const taxObligationSummary = getTaxObligationSummary(companyId);
  const documentSummary = getDocumentSummary(companyId);
  
  // Format currency
  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };
  
  // Format date
  const formatDate = (date: Date): string => {
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };
  
  const modules = [
    {
      name: 'Painel do Contador',
      description: 'Dashboard completo com relatórios e demonstrativos contábeis',
      icon: FileText,
      path: '/accounting/dashboard',
      color: 'bg-blue-600',
    },
    {
      name: 'Integração Fiscal',
      description: 'Importação e validação de documentos fiscais',
      icon: Database,
      path: '/accounting/fiscal',
      color: 'bg-green-600',
    },
    {
      name: 'Geração SPED',
      description: 'Geração de arquivos SPED Fiscal, Contribuições e Contábil',
      icon: FileBarChart,
      path: '/accounting/sped',
      color: 'bg-purple-600',
    },
    {
      name: 'Emissão NFe',
      description: 'Emissão e gerenciamento de documentos fiscais eletrônicos',
      icon: FileDigit,
      path: '/accounting/nfe',
      color: 'bg-amber-600',
    },
    {
      name: 'Cadastro Empresarial',
      description: 'Configurações fiscais e tributárias da empresa',
      icon: Building2,
      path: '/accounting/companies',
      color: 'bg-indigo-600',
    },
    {
      name: 'Módulo de Cadastros',
      description: 'Gerenciamento de clientes, fornecedores e usuários',
      icon: Users,
      path: '/accounting/entities',
      color: 'bg-red-600',
    },
  ];
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900 flex items-center">
          <Calculator className="h-6 w-6 mr-2 text-gray-700" />
          Módulo Contábil-Fiscal
        </h1>
      </div>
      
      {/* Alert Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Certificate Alerts */}
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="bg-blue-50 border-b border-blue-100 px-4 py-3 sm:px-6">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-medium text-blue-800">Certificados Digitais</h2>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                {certificateStatus.validCertificates} válidos
              </span>
            </div>
          </div>
          <div className="px-4 py-3 sm:px-6">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Certificados ativos:</span>
              <span className="font-medium text-green-600">{certificateStatus.validCertificates}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-2">
              <span className="text-gray-500">Certificados expirando:</span>
              <span className="font-medium text-amber-600">{certificateStatus.expiringCertificates}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-2">
              <span className="text-gray-500">Certificados expirados:</span>
              <span className="font-medium text-red-600">{certificateStatus.expiredCertificates}</span>
            </div>
            
            {certificateStatus.expiringCertificates > 0 && (
              <div className="mt-3 p-2 bg-yellow-50 rounded-md border border-yellow-100 flex items-start">
                <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0" />
                <div className="text-xs text-yellow-800">
                  Certificados próximos do vencimento. Realize a renovação para evitar interrupções.
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Tax Obligations */}
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="bg-red-50 border-b border-red-100 px-4 py-3 sm:px-6">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-medium text-red-800">Obrigações Fiscais</h2>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                {taxObligationSummary.pendingObligations} pendentes
              </span>
            </div>
          </div>
          <div className="px-4 py-3 sm:px-6">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Obrigações pendentes:</span>
              <span className="font-medium text-amber-600">{taxObligationSummary.pendingObligations}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-2">
              <span className="text-gray-500">Obrigações atrasadas:</span>
              <span className="font-medium text-red-600">{taxObligationSummary.lateObligations}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-2">
              <span className="text-gray-500">Total a pagar:</span>
              <span className="font-medium text-gray-900">{formatCurrency(taxObligationSummary.totalDue)}</span>
            </div>
            
            {taxObligationSummary.nextDueDates.length > 0 && (
              <div className="mt-3 p-2 bg-blue-50 rounded-md border border-blue-100">
                <div className="text-xs font-medium text-blue-800 mb-1">Próximos vencimentos:</div>
                {taxObligationSummary.nextDueDates.map((obligation, index) => (
                  <div key={index} className="flex justify-between items-center text-xs">
                    <span>{obligation.name}</span>
                    <div className="flex items-center">
                      <span className="mr-1">{formatCurrency(obligation.amount)}</span>
                      <span className="text-gray-500">{formatDate(obligation.dueDate)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        
        {/* Document Status */}
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="bg-green-50 border-b border-green-100 px-4 py-3 sm:px-6">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-medium text-green-800">Documentos Fiscais</h2>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                {documentSummary.issuedDocuments} emitidos
              </span>
            </div>
          </div>
          <div className="px-4 py-3 sm:px-6">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Documentos emitidos:</span>
              <span className="font-medium text-green-600">{documentSummary.issuedDocuments}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-2">
              <span className="text-gray-500">Documentos pendentes:</span>
              <span className="font-medium text-amber-600">{documentSummary.pendingDocuments}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-2">
              <span className="text-gray-500">Documentos cancelados:</span>
              <span className="font-medium text-red-600">{documentSummary.cancelledDocuments}</span>
            </div>
            
            {documentSummary.lastDocuments.length > 0 && (
              <div className="mt-3 p-2 bg-gray-50 rounded-md border border-gray-100">
                <div className="text-xs font-medium text-gray-700 mb-1">Últimos documentos:</div>
                <div className="max-h-20 overflow-y-auto">
                  {documentSummary.lastDocuments.map((doc, index) => (
                    <div key={index} className="flex justify-between items-center text-xs py-1 border-b border-gray-100 last:border-0">
                      <span className="text-gray-800">{doc.type} {doc.number}</span>
                      <span className="text-gray-500">{formatDate(doc.issueDate)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Calendar & Upcoming Activities */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg font-medium leading-6 text-gray-900 flex items-center">
            <Calendar className="h-5 w-5 mr-2 text-gray-700" />
            Calendário Fiscal e Próximas Atividades
          </h3>
        </div>
        <div className="px-4 py-5 sm:p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Upcoming Tax Obligations */}
            <div className="col-span-1 bg-gray-50 rounded-lg p-4">
              <h4 className="text-sm font-medium text-gray-900 mb-3">Próximas Obrigações</h4>
              <div className="space-y-3">
                {taxObligationSummary.nextDueDates.map((obligation, index) => (
                  <div key={index} className="flex items-start p-2 bg-white rounded-md shadow-sm">
                    <div className="flex-shrink-0">
                      <span className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-red-100 text-red-600">
                        <Clock className="h-4 w-4" />
                      </span>
                    </div>
                    <div className="ml-3 flex-1">
                      <div className="text-sm font-medium text-gray-900">{obligation.name}</div>
                      <div className="text-xs text-gray-500 flex justify-between mt-1">
                        <span>Vencimento: {formatDate(obligation.dueDate)}</span>
                        <span className="font-medium text-gray-700">{formatCurrency(obligation.amount)}</span>
                      </div>
                    </div>
                  </div>
                ))}
                
                {taxObligationSummary.nextDueDates.length === 0 && (
                  <div className="text-center py-4 text-gray-500">
                    Nenhuma obrigação pendente para os próximos dias.
                  </div>
                )}
                
                <button
                  type="button"
                  className="mt-2 w-full flex justify-center items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                  onClick={() => navigate('/accounting/fiscal')}
                >
                  Ver todas obrigações
                </button>
              </div>
            </div>
            
            {/* Calendar for the month */}
            <div className="col-span-2 bg-gray-50 rounded-lg p-4">
              <h4 className="text-sm font-medium text-gray-900 mb-3">Calendário de Obrigações - Outubro/2023</h4>
              <div className="grid grid-cols-7 gap-1">
                {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((day, i) => (
                  <div key={i} className="text-xs font-medium text-gray-500 text-center p-1">
                    {day}
                  </div>
                ))}
                {Array(35).fill(null).map((_, i) => {
                  const day = i - 6 + 1; // Adjust to start October on Sunday (day 1)
                  const isCurrentMonth = day > 0 && day <= 31;
                  const isToday = day === new Date().getDate() && new Date().getMonth() === 9; // October is 9 in JS
                  
                  // Check if this day has tax obligations
                  const hasTaxObligation = taxObligationSummary.nextDueDates.some(
                    obl => obl.dueDate.getDate() === day && obl.dueDate.getMonth() === 9
                  );
                  
                  const hasLateObligation = day < new Date().getDate() && hasTaxObligation;
                  
                  return (
                    <div 
                      key={i} 
                      className={`
                        p-1 text-xs border rounded-md flex flex-col justify-between h-12
                        ${!isCurrentMonth ? 'text-gray-300 bg-gray-100 border-gray-100' : 'text-gray-700 bg-white border-gray-200'}
                        ${isToday ? 'border-blue-500 bg-blue-50' : ''}
                        ${hasTaxObligation && !hasLateObligation ? 'border-amber-500 bg-amber-50' : ''}
                        ${hasLateObligation ? 'border-red-500 bg-red-50' : ''}
                      `}
                    >
                      <div className="flex justify-between items-start">
                        <span className={`font-medium ${isToday ? 'text-blue-700' : ''}`}>
                          {isCurrentMonth ? day : ''}
                        </span>
                        {hasTaxObligation && (
                          <span className={`inline-block h-2 w-2 rounded-full ${hasLateObligation ? 'bg-red-500' : 'bg-amber-500'}`}></span>
                        )}
                      </div>
                      {hasTaxObligation && (
                        <div className="text-[10px] mt-1 truncate">
                          {taxObligationSummary.nextDueDates.filter(
                            obl => obl.dueDate.getDate() === day && obl.dueDate.getMonth() === 9
                          )[0]?.name.split(' ')[0]}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-3 flex justify-center space-x-4 text-xs">
                <div className="flex items-center">
                  <span className="inline-block h-2 w-2 rounded-full bg-blue-500 mr-1"></span>
                  <span>Hoje</span>
                </div>
                <div className="flex items-center">
                  <span className="inline-block h-2 w-2 rounded-full bg-amber-500 mr-1"></span>
                  <span>Vencimento Próximo</span>
                </div>
                <div className="flex items-center">
                  <span className="inline-block h-2 w-2 rounded-full bg-red-500 mr-1"></span>
                  <span>Vencimento Atrasado</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Module Navigation */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {modules.map((module, index) => (
          <div 
            key={index} 
            className="bg-white shadow rounded-lg overflow-hidden hover:shadow-md transition-shadow"
            onClick={() => navigate(module.path)}
          >
            <div className={`${module.color} px-4 py-5 sm:p-6 flex items-center`}>
              <div className="rounded-md bg-white bg-opacity-30 p-3">
                <module.icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="ml-3 text-lg font-medium text-white">{module.name}</h3>
            </div>
            <div className="px-4 py-4 sm:px-6 flex justify-between items-center">
              <p className="text-sm text-gray-500">{module.description}</p>
              <ChevronRight className="h-5 w-5 text-gray-400" />
            </div>
          </div>
        ))}
      </div>
      
      {/* Notice */}
      <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-md">
        <div className="flex">
          <div className="flex-shrink-0">
            <Info className="h-5 w-5 text-blue-600" />
          </div>
          <div className="ml-3">
            <p className="text-sm text-blue-700">
              As funcionalidades contábil-fiscais estão em constante atualização para atender à legislação. Certifique-se de manter o sistema atualizado.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};