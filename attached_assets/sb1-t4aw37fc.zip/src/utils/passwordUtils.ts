import { PasswordComplexityResult } from '../types/userManagement';

/**
 * Validates password complexity
 * @param password The password to validate
 * @returns Object containing validation results
 */
export const validatePasswordComplexity = (password: string): PasswordComplexityResult => {
  const minLength = 8;
  const hasMinLength = password.length >= minLength;
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password);
  
  // Calculate score (0-5)
  const score = [hasMinLength, hasUpperCase, hasLowerCase, hasNumber, hasSpecialChar]
    .filter(Boolean).length;
  
  const valid = hasMinLength && hasUpperCase && hasLowerCase && hasNumber && hasSpecialChar;
  
  return {
    valid,
    hasMinLength,
    hasUpperCase,
    hasLowerCase,
    hasNumber,
    hasSpecialChar,
    score
  };
};

/**
 * Get password strength label based on score
 * @param score Password strength score (0-5)
 * @returns String label indicating password strength
 */
export const getPasswordStrengthLabel = (score: number): string => {
  switch(score) {
    case 0:
    case 1:
      return 'Very Weak';
    case 2:
      return 'Weak';
    case 3:
      return 'Fair';
    case 4:
      return 'Good';
    case 5:
      return 'Strong';
    default:
      return 'Unknown';
  }
};

/**
 * Get color class for password strength
 * @param score Password strength score (0-5)
 * @returns Tailwind color class
 */
export const getPasswordStrengthColor = (score: number): string => {
  switch(score) {
    case 0:
    case 1:
      return 'bg-red-500';
    case 2:
      return 'bg-orange-500';
    case 3:
      return 'bg-yellow-500';
    case 4:
      return 'bg-green-500';
    case 5:
      return 'bg-green-600';
    default:
      return 'bg-gray-300';
  }
};

/**
 * Compare two passwords to check if they match
 * @param password The password
 * @param confirmPassword The confirmation password
 * @returns Boolean indicating if passwords match
 */
export const doPasswordsMatch = (password: string, confirmPassword: string): boolean => {
  return password === confirmPassword;
};