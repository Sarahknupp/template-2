# app_controlaivendas

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/Sarahknupp/app_controlaivendas)