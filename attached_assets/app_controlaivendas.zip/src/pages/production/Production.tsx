import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Clipboard, Calendar, Plus, ChefHat, Cake, Utensils, Clock, AlertTriangle,
  BarChart2, Filter, ArrowRight, Users, FileText, Search, TrendingUp
} from 'lucide-react';
import { 
  mockProductionOrders, 
  mockProductionAreas, 
  mockProductivityReports,
  getTodaysProduction
} from '../../data/mockData';

export const Production: React.FC = () => {
  const navigate = useNavigate();
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterArea, setFilterArea] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Get today's production
  const todayProduction = getTodaysProduction();
  
  // Filter orders
  const filteredOrders = mockProductionOrders.filter(order => {
    const matchesSearch = searchTerm === '' || 
                         order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (order.clientName && order.clientName.toLowerCase().includes(searchTerm.toLowerCase())) ||
                         order.items.some(item => item.productName.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = filterStatus === 'all' || order.status === filterStatus;
    const matchesArea = filterArea === 'all' || 
                       order.assignedArea === filterArea || 
                       (order.assignedArea === 'multiple' && order.items.some(item => item.area === filterArea));
    const matchesPriority = filterPriority === 'all' || order.priority === filterPriority;
    
    return matchesSearch && matchesStatus && matchesArea && matchesPriority;
  });
  
  // Calculate area stats
  const areaStats = mockProductionAreas.map(area => {
    const areaOrders = mockProductionOrders.filter(order => 
      order.assignedArea === area.id ||
      (order.assignedArea === 'multiple' && order.items.some(item => item.area === area.id))
    );
    
    const pendingOrders = areaOrders.filter(order => order.status === 'pending').length;
    const inProductionOrders = areaOrders.filter(order => order.status === 'in-production').length;
    
    return {
      ...area,
      pendingOrders,
      inProductionOrders
    };
  });
  
  // Productivity data
  const productivityData = mockProductivityReports[0];
  
  // Format relative time
  const formatRelativeTime = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.round((date.getTime() - now.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 0) {
      return `Atrasado por ${Math.abs(diffInHours)}h`;
    } else if (diffInHours === 0) {
      const diffInMinutes = Math.round((date.getTime() - now.getTime()) / (1000 * 60));
      return diffInMinutes <= 0 ? 'Agora' : `Em ${diffInMinutes}m`;
    } else if (diffInHours < 24) {
      return `Em ${diffInHours}h`;
    } else {
      const days = Math.floor(diffInHours / 24);
      return `Em ${days}d`;
    }
  };
  
  // Get priority class
  const getPriorityClass = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Gestão de Produção</h1>
        <button
          type="button"
          onClick={() => navigate('/production/order/new')}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500"
        >
          <Plus className="h-4 w-4 mr-1" />
          Nova Ordem de Produção
        </button>
      </div>
      
      {/* Production Areas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {areaStats.map(area => (
          <div key={area.id} className="bg-white shadow rounded-lg overflow-hidden">
            <div className={`p-4 ${
              area.name === 'Cozinha' ? 'bg-red-50 border-b border-red-100' :
              area.name === 'Confeitaria' ? 'bg-purple-50 border-b border-purple-100' :
              'bg-amber-50 border-b border-amber-100'
            }`}>
              <div className="flex items-center">
                {area.name === 'Cozinha' ? (
                  <ChefHat className="h-5 w-5 mr-2 text-red-600" />
                ) : area.name === 'Confeitaria' ? (
                  <Cake className="h-5 w-5 mr-2 text-purple-600" />
                ) : (
                  <Utensils className="h-5 w-5 mr-2 text-amber-600" />
                )}
                <h3 className="text-lg font-medium">
                  {area.name}
                </h3>
                <div className="ml-auto">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    area.currentUtilization > 75 
                      ? 'bg-red-100 text-red-800' 
                      : area.currentUtilization > 50
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-green-100 text-green-800'
                  }`}>
                    {area.currentUtilization}% Utilização
                  </span>
                </div>
              </div>
            </div>
            
            <div className="p-4">
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-gray-50 rounded p-3 text-center">
                  <div className="text-xs text-gray-500">Ordens Pendentes</div>
                  <div className="text-xl font-bold text-amber-600">{area.pendingOrders}</div>
                </div>
                <div className="bg-gray-50 rounded p-3 text-center">
                  <div className="text-xs text-gray-500">Em Produção</div>
                  <div className="text-xl font-bold text-blue-600">{area.inProductionOrders}</div>
                </div>
              </div>
              
              <div className="space-y-3">
                {area.activeProduction.length > 0 ? (
                  area.activeProduction.map(prodId => {
                    const productionPlan = todayProduction?.find(p => p.id === prodId);
                    if (!productionPlan) return null;
                    const totalQuantity = productionPlan.products.reduce((sum, p) => sum + p.quantity, 0);
                    const completedQuantity = productionPlan.products.reduce((sum, p) => sum + p.completed, 0);
                    const progressPercentage = Math.round((completedQuantity / totalQuantity) * 100);
                    
                    return (
                      <div key={prodId} className="border border-gray-100 rounded p-2">
                        <div className="flex justify-between items-center">
                          <div className="text-sm font-medium">{productionPlan.products[0].productName}</div>
                          <div className="text-xs">{completedQuantity}/{totalQuantity}</div>
                        </div>
                        <div className="mt-1 w-full bg-gray-200 rounded-full h-1.5">
                          <div 
                            className="bg-amber-500 h-1.5 rounded-full" 
                            style={{ width: `${progressPercentage}%` }}
                          ></div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="text-center text-sm text-gray-500 py-2">
                    Nenhuma produção ativa
                  </div>
                )}
              </div>
              
              <div className="mt-4">
                <button
                  type="button"
                  onClick={() => navigate(`/production/${area.name === 'Cozinha' ? 'kitchen' : area.name === 'Confeitaria' ? 'confectionery' : 'bakery'}`)}
                  className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500"
                >
                  Gerenciar {area.name}
                  <ArrowRight className="ml-1 h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Production Orders */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium text-gray-900">
              Ordens de Produção
            </h2>
          </div>
          
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                  placeholder="Pesquisar ordens..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            
            <div>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Filter className="h-5 w-5 text-gray-400" />
                </div>
                <select
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                >
                  <option value="all">Todos os Status</option>
                  <option value="pending">Pendentes</option>
                  <option value="in-production">Em Produção</option>
                  <option value="completed">Concluídos</option>
                  <option value="delivered">Entregues</option>
                </select>
              </div>
            </div>
            
            <div>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Filter className="h-5 w-5 text-gray-400" />
                </div>
                <select
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                  value={filterArea}
                  onChange={(e) => setFilterArea(e.target.value)}
                >
                  <option value="all">Todas as Áreas</option>
                  <option value="kitchen">Cozinha</option>
                  <option value="confectionery">Confeitaria</option>
                  <option value="bakery">Panificação</option>
                  <option value="multiple">Múltiplas Áreas</option>
                </select>
              </div>
            </div>
            
            <div>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Filter className="h-5 w-5 text-gray-400" />
                </div>
                <select
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                  value={filterPriority}
                  onChange={(e) => setFilterPriority(e.target.value)}
                >
                  <option value="all">Todas as Prioridades</option>
                  <option value="high">Alta</option>
                  <option value="medium">Média</option>
                  <option value="low">Baixa</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ordem
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data/Cliente
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Itens
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Área
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status/Prioridade
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Prazo
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredOrders.map(order => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-amber-600">{order.orderNumber}</div>
                    <div className="text-xs text-gray-500">
                      <div className="flex items-center mt-1">
                        <Clock className="h-3 w-3 mr-1 text-gray-400" />
                        {order.totalEstimatedTime} min
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{new Date(order.date).toLocaleDateString('pt-BR')}</div>
                    {order.clientName && (
                      <div className="text-xs text-gray-500">{order.clientName}</div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {order.items.length} itens
                    </div>
                    <div className="text-xs text-gray-500">
                      {order.items[0]?.productName}{order.items.length > 1 ? ` + ${order.items.length - 1} mais` : ''}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      order.assignedArea === 'kitchen' 
                        ? 'bg-red-100 text-red-800' 
                        : order.assignedArea === 'confectionery'
                          ? 'bg-purple-100 text-purple-800'
                          : order.assignedArea === 'bakery'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-blue-100 text-blue-800'
                    }`}>
                      {order.assignedArea === 'kitchen' 
                        ? 'Cozinha' 
                        : order.assignedArea === 'confectionery'
                          ? 'Confeitaria'
                          : order.assignedArea === 'bakery'
                            ? 'Panificação'
                            : 'Múltiplas'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      order.status === 'pending' 
                        ? 'bg-yellow-100 text-yellow-800' 
                        : order.status === 'in-production'
                          ? 'bg-blue-100 text-blue-800'
                          : order.status === 'completed'
                            ? 'bg-green-100 text-green-800'
                            : order.status === 'delivered'
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'bg-red-100 text-red-800'
                    }`}>
                      {order.status === 'pending' 
                        ? 'Pendente' 
                        : order.status === 'in-production'
                          ? 'Em Produção'
                          : order.status === 'completed'
                            ? 'Concluído'
                            : order.status === 'delivered'
                              ? 'Entregue'
                              : 'Cancelado'}
                    </span>
                    
                    <div className="mt-1">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityClass(order.priority)}`}>
                        Prioridade {order.priority === 'high' 
                          ? 'Alta' 
                          : order.priority === 'medium'
                            ? 'Média'
                            : 'Baixa'}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`text-sm font-medium ${
                      new Date(order.dueDate) < new Date() 
                        ? 'text-red-600' 
                        : 'text-gray-900'
                    }`}>
                      {new Date(order.dueDate).toLocaleDateString('pt-BR')} {new Date(order.dueDate).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}
                    </div>
                    <div className="text-xs text-gray-500">
                      {formatRelativeTime(new Date(order.dueDate))}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <button
                      onClick={() => navigate(`/production/order/${order.id}`)}
                      className="inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs font-medium rounded text-amber-700 bg-amber-100 hover:bg-amber-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500"
                    >
                      Detalhes
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {filteredOrders.length === 0 && (
            <div className="text-center py-10">
              <Clipboard className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhuma ordem de produção encontrada</h3>
              <p className="mt-1 text-sm text-gray-500">
                Ajuste os filtros ou crie uma nova ordem de produção.
              </p>
              <div className="mt-6">
                <button
                  type="button"
                  onClick={() => navigate('/production/order/new')}
                  className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500"
                >
                  <Plus className="-ml-1 mr-2 h-5 w-5" aria-hidden="true" />
                  Nova Ordem de Produção
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Productivity Overview */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-gray-900 flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-amber-600" />
              Visão Geral de Produtividade
            </h2>
            <button
              type="button"
              onClick={() => navigate('/reports')}
              className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500"
            >
              <BarChart2 className="h-4 w-4 mr-1" />
              Ver Relatórios Detalhados
            </button>
          </div>
        </div>
        
        <div className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-gray-50 rounded-md p-4 text-center">
              <h3 className="text-sm font-medium text-gray-500">Taxa de Conclusão</h3>
              <div className="mt-1 text-2xl font-bold text-amber-600">{productivityData.completionRate}%</div>
            </div>
            <div className="bg-gray-50 rounded-md p-4 text-center">
              <h3 className="text-sm font-medium text-gray-500">Taxa de Desperdício</h3>
              <div className="mt-1 text-2xl font-bold text-amber-600">{productivityData.wasteRate}%</div>
            </div>
            <div className="bg-gray-50 rounded-md p-4 text-center">
              <h3 className="text-sm font-medium text-gray-500">Tempo Médio de Produção</h3>
              <div className="mt-1 text-2xl font-bold text-amber-600">{productivityData.averageProductionTime} min</div>
            </div>
            <div className="bg-gray-50 rounded-md p-4 text-center">
              <h3 className="text-sm font-medium text-gray-500">Total Produzido</h3>
              <div className="mt-1 text-2xl font-bold text-amber-600">{productivityData.totalProduction} itens</div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {productivityData.areas.map(area => (
              <div key={area.area} className={`border rounded-md overflow-hidden ${
                area.area === 'kitchen' ? 'border-red-200' : 
                area.area === 'confectionery' ? 'border-purple-200' :
                'border-amber-200'
              }`}>
                <div className={`px-4 py-3 ${
                  area.area === 'kitchen' ? 'bg-red-50' : 
                  area.area === 'confectionery' ? 'bg-purple-50' :
                  'bg-amber-50'
                }`}>
                  <div className="flex items-center">
                    {area.area === 'kitchen' ? (
                      <ChefHat className="h-5 w-5 mr-2 text-red-600" />
                    ) : area.area === 'confectionery' ? (
                      <Cake className="h-5 w-5 mr-2 text-purple-600" />
                    ) : (
                      <Utensils className="h-5 w-5 mr-2 text-amber-600" />
                    )}
                    <h3 className="text-sm font-medium">
                      {area.area === 'kitchen' ? 'Cozinha' : 
                       area.area === 'confectionery' ? 'Confeitaria' : 
                       'Panificação'}
                    </h3>
                  </div>
                </div>
                
                <div className="p-4 bg-white">
                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <div className="text-center">
                      <div className="text-xs text-gray-500">Eficiência</div>
                      <div className="text-lg font-bold text-gray-900">{area.efficiencyRate}%</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xs text-gray-500">Tempo Médio</div>
                      <div className="text-lg font-bold text-gray-900">{area.avgCompletionTime}min</div>
                    </div>
                  </div>
                  
                  <div className="text-xs text-gray-500 mb-2">Itens Mais Produzidos:</div>
                  {area.topProducedItems.slice(0, 3).map(item => (
                    <div key={item.productId} className="flex justify-between items-center mb-1 text-sm">
                      <span className="truncate">{item.productName}</span>
                      <span className="font-medium">{item.quantity}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};