import React, { useState, useEffect } from 'react';
import { Building2, Plus, Edit, Trash2, ChevronDown, ChevronRight, FileText, Settings, Upload, Shield, Download, Save, Check, X, Image, Camera } from 'lucide-react';
import { mockCompanies, mockDigitalCertificates, mockTaxParameters } from '../../data/mockAccountingData';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../../components/ui/dialog';
import { Button } from '../../components/ui/button';
import { Label } from '../../components/ui/label';
import { Input } from '../../components/ui/input';
import toast from 'react-hot-toast';

export const CompanyManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'companies' | 'certificates' | 'parameters'>('companies');
  const [expandedCompany, setExpandedCompany] = useState<string | null>(null);
  const [editMode, setEditMode] = useState<boolean>(false);
  const [selectedCompany, setSelectedCompany] = useState<string | null>(null);
  const [showAddCompanyModal, setShowAddCompanyModal] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [showLogoModal, setShowLogoModal] = useState<boolean>(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState<boolean>(false);
  const [confirmAction, setConfirmAction] = useState<() => void>(() => {});
  const [confirmMessage, setConfirmMessage] = useState<string>('');
  const [companyLogo, setCompanyLogo] = useState<string | null>(null);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  
  // New company form state
  const [newCompanyForm, setNewCompanyForm] = useState({
    companyName: '',
    tradeName: '',
    cnpj: '',
    stateRegistration: '',
    municipalRegistration: '',
    address: {
      street: '',
      number: '',
      complement: '',
      district: '',
      city: '',
      state: '',
      zipCode: '',
      country: 'Brasil',
    },
    phone: '',
    email: '',
    taxRegime: 'simples',
    economicActivity: '',
    cnae: '',
    openingDate: new Date().toISOString().split('T')[0],
    accountingResponsible: '',
    status: 'active',
  });

  // Form errors state
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  
  // Toggle company expansion
  const toggleCompanyExpansion = (id: string) => {
    if (expandedCompany === id) {
      setExpandedCompany(null);
    } else {
      setExpandedCompany(id);
      setSelectedCompany(id);
      
      // Load company logo (if any)
      const company = mockCompanies.find(c => c.id === id);
      if (company && company.logo) {
        setCompanyLogo(company.logo);
      } else {
        setCompanyLogo(null);
      }
    }
  };
  
  // Format date
  const formatDate = (date: Date): string => {
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };
  
  // Get certificate status badge
  const getCertificateStatusBadge = (status: string) => {
    switch (status) {
      case 'valid':
        return 'bg-green-100 text-green-800';
      case 'expired':
        return 'bg-red-100 text-red-800';
      case 'revoked':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Get certificate icon based on type
  const getCertificateTypeIcon = (type: string) => {
    if (type === 'a1') {
      return <FileText className="h-5 w-5 text-blue-600" />;
    } else {
      return <Shield className="h-5 w-5 text-indigo-600" />;
    }
  };
  
  // Filter certificates for selected company
  const companyCertificates = mockDigitalCertificates.filter(
    cert => cert.companyId === selectedCompany
  );
  
  // Filter tax parameters for selected company
  const companyTaxParameters = mockTaxParameters.filter(
    param => param.companyId === selectedCompany
  );

  // Validate CNPJ format
  const isValidCNPJ = (cnpj: string): boolean => {
    const cnpjRegex = /^\d{2}\.\d{3}\.\d{3}\/\d{4}\-\d{2}$/;
    return cnpjRegex.test(cnpj);
  };

  // Mask CNPJ input
  const maskCNPJ = (value: string): string => {
    return value
      .replace(/\D/g, '') // Remove all non-digits
      .replace(/^(\d{2})(\d)/, '$1.$2') // Place dot after the first 2 digits
      .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3') // Place dot after the next 3 digits
      .replace(/\.(\d{3})(\d)/, '.$1/$2') // Place slash after the next 3 digits
      .replace(/\/(\d{4})(\d)/, '/$1-$2') // Place dash after the next 4 digits
      .replace(/(-\d{2})\d+?$/, '$1'); // Limit to 14 digits (CNPJ length)
  };

  // Handle input change for new company form
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    // Handle nested address fields
    if (name.startsWith('address.')) {
      const addressField = name.split('.')[1];
      setNewCompanyForm(prev => ({
        ...prev,
        address: {
          ...prev.address,
          [addressField]: value
        }
      }));
    } else if (name === 'cnpj') {
      // Apply CNPJ mask
      const maskedValue = maskCNPJ(value);
      setNewCompanyForm(prev => ({ ...prev, [name]: maskedValue }));
    } else {
      // Handle regular fields
      setNewCompanyForm(prev => ({ ...prev, [name]: value }));
    }
    
    // Clear error for this field if any
    if (formErrors[name]) {
      setFormErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  // Validate the company form
  const validateCompanyForm = (): boolean => {
    const errors: Record<string, string> = {};
    
    // Required fields
    if (!newCompanyForm.companyName.trim()) {
      errors['companyName'] = 'Razão social é obrigatória';
    }
    
    if (!newCompanyForm.tradeName.trim()) {
      errors['tradeName'] = 'Nome fantasia é obrigatório';
    }
    
    if (!newCompanyForm.cnpj.trim()) {
      errors['cnpj'] = 'CNPJ é obrigatório';
    } else if (!isValidCNPJ(newCompanyForm.cnpj)) {
      errors['cnpj'] = 'CNPJ inválido. Formato esperado: 00.000.000/0000-00';
    }
    
    if (!newCompanyForm.address.street.trim()) {
      errors['address.street'] = 'Endereço é obrigatório';
    }
    
    if (!newCompanyForm.address.number.trim()) {
      errors['address.number'] = 'Número é obrigatório';
    }
    
    if (!newCompanyForm.address.city.trim()) {
      errors['address.city'] = 'Cidade é obrigatória';
    }
    
    if (!newCompanyForm.address.state.trim()) {
      errors['address.state'] = 'Estado é obrigatório';
    }
    
    if (!newCompanyForm.address.zipCode.trim()) {
      errors['address.zipCode'] = 'CEP é obrigatório';
    }
    
    if (!newCompanyForm.phone.trim()) {
      errors['phone'] = 'Telefone é obrigatório';
    }
    
    if (!newCompanyForm.email.trim()) {
      errors['email'] = 'Email é obrigatório';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newCompanyForm.email)) {
      errors['email'] = 'Email inválido';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle form submission for new company
  const handleAddCompany = () => {
    if (!validateCompanyForm()) {
      return;
    }
    
    // In a real app, this would be an API call to save the company
    // For now, we'll just show a success message
    toast.success('Empresa adicionada com sucesso!');
    setShowAddCompanyModal(false);
    
    // Reset form
    setNewCompanyForm({
      companyName: '',
      tradeName: '',
      cnpj: '',
      stateRegistration: '',
      municipalRegistration: '',
      address: {
        street: '',
        number: '',
        complement: '',
        district: '',
        city: '',
        state: '',
        zipCode: '',
        country: 'Brasil',
      },
      phone: '',
      email: '',
      taxRegime: 'simples',
      economicActivity: '',
      cnae: '',
      openingDate: new Date().toISOString().split('T')[0],
      accountingResponsible: '',
      status: 'active',
    });
  };

  // Handle opening settings modal
  const handleOpenSettings = (companyId: string) => {
    setSelectedCompany(companyId);
    setShowSettingsModal(true);
  };

  // Handle saving settings
  const handleSaveSettings = () => {
    // In a real app, this would be an API call to save the settings
    toast.success('Configurações salvas com sucesso!');
    setShowSettingsModal(false);
  };

  // Handle logo management
  const handleOpenLogoModal = () => {
    setShowLogoModal(true);
  };

  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Validate file type
      if (!file.type.match('image/jpeg') && !file.type.match('image/png')) {
        toast.error('Apenas arquivos JPEG e PNG são permitidos.');
        return;
      }
      
      // Validate file size (max 2MB)
      if (file.size > 2 * 1024 * 1024) {
        toast.error('O tamanho máximo permitido é 2MB.');
        return;
      }
      
      setLogoFile(file);
      
      // Preview the image
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setCompanyLogo(e.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUploadLogo = () => {
    if (!logoFile) {
      toast.error('Nenhum arquivo selecionado.');
      return;
    }
    
    // In a real app, this would be an API call to upload the logo
    // For now, we'll just store it in localStorage for demo purposes
    localStorage.setItem('companyLogo', companyLogo as string);
    
    toast.success('Logo atualizado com sucesso!');
    setShowLogoModal(false);
  };

  const handleRemoveLogo = () => {
    // Show confirmation dialog
    setConfirmMessage('Tem certeza que deseja remover o logo da empresa?');
    setConfirmAction(() => () => {
      setCompanyLogo(null);
      setLogoFile(null);
      localStorage.removeItem('companyLogo');
      toast.success('Logo removido com sucesso!');
      setShowLogoModal(false);
      setShowConfirmDialog(false);
    });
    setShowConfirmDialog(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900 flex items-center">
          <Building2 className="h-6 w-6 mr-2 text-gray-700" />
          Cadastro Empresarial
        </h1>
        
        <div className="flex space-x-3">
          <button
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            onClick={() => setShowAddCompanyModal(true)}
          >
            <Plus className="h-4 w-4 mr-1" />
            Nova Empresa
          </button>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('companies')}
              className={`w-1/3 py-4 px-1 text-center border-b-2 font-medium text-sm ${
                activeTab === 'companies'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Empresas
            </button>
            <button
              onClick={() => setActiveTab('certificates')}
              className={`w-1/3 py-4 px-1 text-center border-b-2 font-medium text-sm ${
                activeTab === 'certificates'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Certificados Digitais
            </button>
            <button
              onClick={() => setActiveTab('parameters')}
              className={`w-1/3 py-4 px-1 text-center border-b-2 font-medium text-sm ${
                activeTab === 'parameters'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Parâmetros Fiscais
            </button>
          </nav>
        </div>
        
        {/* Companies Tab Content */}
        {activeTab === 'companies' && (
          <div className="px-4 py-5 sm:p-6">
            <div className="space-y-4">
              {mockCompanies.map((company) => (
                <div key={company.id} className="border border-gray-200 rounded-md overflow-hidden shadow-sm">
                  <div 
                    className={`px-4 py-3 flex items-center justify-between cursor-pointer ${
                      expandedCompany === company.id ? 'bg-blue-50 border-b border-blue-100' : 'bg-white'
                    }`}
                    onClick={() => toggleCompanyExpansion(company.id)}
                  >
                    <div className="flex items-center">
                      <Building2 className={`h-5 w-5 mr-2 ${
                        expandedCompany === company.id ? 'text-blue-600' : 'text-gray-500'
                      }`} />
                      <div>
                        <div className="text-sm font-medium text-gray-900">{company.companyName}</div>
                        <div className="text-xs text-gray-500">CNPJ: {company.cnpj}</div>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mr-2 ${
                        company.status === 'active' 
                          ? 'bg-green-100 text-green-800' 
                          : company.status === 'inactive'
                            ? 'bg-gray-100 text-gray-800'
                            : 'bg-red-100 text-red-800'
                      }`}>
                        {company.status === 'active' 
                          ? 'Ativo' 
                          : company.status === 'inactive'
                            ? 'Inativo'
                            : 'Suspenso'}
                      </span>
                      {expandedCompany === company.id ? (
                        <ChevronDown className="h-5 w-5 text-gray-400" />
                      ) : (
                        <ChevronRight className="h-5 w-5 text-gray-400" />
                      )}
                    </div>
                  </div>
                  
                  {expandedCompany === company.id && (
                    <div className="p-4 bg-white">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-900 mb-2">Informações Gerais</h4>
                          <div className="bg-gray-50 p-3 rounded-md">
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <div className="text-xs text-gray-500">Razão Social</div>
                                <div className="text-sm">{company.companyName}</div>
                              </div>
                              <div>
                                <div className="text-xs text-gray-500">Nome Fantasia</div>
                                <div className="text-sm">{company.tradeName}</div>
                              </div>
                              <div>
                                <div className="text-xs text-gray-500">CNPJ</div>
                                <div className="text-sm">{company.cnpj}</div>
                              </div>
                              <div>
                                <div className="text-xs text-gray-500">Inscrição Estadual</div>
                                <div className="text-sm">{company.stateRegistration}</div>
                              </div>
                              <div>
                                <div className="text-xs text-gray-500">Inscrição Municipal</div>
                                <div className="text-sm">{company.municipalRegistration || 'N/A'}</div>
                              </div>
                              <div>
                                <div className="text-xs text-gray-500">Regime Tributário</div>
                                <div className="text-sm capitalize">{company.taxRegime}</div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium text-gray-900 mb-2">Endereço e Contato</h4>
                          <div className="bg-gray-50 p-3 rounded-md">
                            <div>
                              <div className="text-xs text-gray-500">Endereço</div>
                              <div className="text-sm">
                                {company.address.street}, {company.address.number}
                                {company.address.complement ? `, ${company.address.complement}` : ''}
                              </div>
                              <div className="text-sm">
                                {company.address.district}, {company.address.city} - {company.address.state}
                              </div>
                              <div className="text-sm">
                                CEP: {company.address.zipCode}
                              </div>
                            </div>
                            <div className="mt-2 grid grid-cols-2 gap-2">
                              <div>
                                <div className="text-xs text-gray-500">Telefone</div>
                                <div className="text-sm">{company.phone}</div>
                              </div>
                              <div>
                                <div className="text-xs text-gray-500">E-mail</div>
                                <div className="text-sm">{company.email}</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <h4 className="text-sm font-medium text-gray-900 mb-2">Informações Fiscais</h4>
                        <div className="bg-gray-50 p-3 rounded-md">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                            <div>
                              <div className="text-xs text-gray-500">CNAE Principal</div>
                              <div className="text-sm">{company.cnae}</div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-500">Atividade Econômica</div>
                              <div className="text-sm">{company.economicActivity}</div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-500">Data de Abertura</div>
                              <div className="text-sm">{formatDate(company.openingDate)}</div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-500">Contador Responsável</div>
                              <div className="text-sm">{company.accountingResponsible}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Company Logo Management */}
                      <div className="mb-4">
                        <h4 className="text-sm font-medium text-gray-900 mb-2">Logotipo da Empresa</h4>
                        <div className="bg-gray-50 p-3 rounded-md flex items-center justify-between">
                          <div className="flex items-center">
                            {companyLogo ? (
                              <div className="h-12 w-32 bg-white rounded border border-gray-200 flex items-center justify-center overflow-hidden">
                                <img 
                                  src={companyLogo} 
                                  alt="Logo" 
                                  className="max-h-full max-w-full object-contain" 
                                />
                              </div>
                            ) : (
                              <div className="h-12 w-32 bg-white rounded border border-gray-200 flex items-center justify-center">
                                <Building2 className="h-6 w-6 text-gray-400" />
                              </div>
                            )}
                            <div className="ml-3">
                              <div className="text-xs text-gray-500">Dimensões recomendadas</div>
                              <div className="text-sm">200x60 pixels</div>
                            </div>
                          </div>
                          
                          <button
                            className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                            onClick={handleOpenLogoModal}
                          >
                            <Image className="h-4 w-4 mr-1" />
                            {companyLogo ? 'Alterar Logo' : 'Configurar Logo'}
                          </button>
                        </div>
                      </div>
                      
                      {company.branches.length > 1 && (
                        <div className="mb-4">
                          <h4 className="text-sm font-medium text-gray-900 mb-2">Filiais</h4>
                          <div className="bg-gray-50 p-2 rounded-md">
                            <div className="space-y-2">
                              {company.branches.filter(branch => !branch.isHeadquarters).map(branch => (
                                <div key={branch.id} className="p-2 bg-white rounded border border-gray-200">
                                  <div className="flex justify-between">
                                    <div>
                                      <div className="text-sm font-medium">{branch.tradeName}</div>
                                      <div className="text-xs text-gray-500">CNPJ: {branch.cnpj}</div>
                                    </div>
                                    <div className="text-xs text-gray-500">
                                      {branch.address.city} - {branch.address.state}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                      
                      <div className="flex justify-end space-x-3">
                        <button
                          className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                          onClick={() => handleOpenSettings(company.id)}
                        >
                          <Settings className="h-4 w-4 mr-1" />
                          Configurações
                        </button>
                        <button
                          className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                          onClick={() => setEditMode(true)}
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Editar
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              
              {/* Add New Company Card */}
              <div 
                className="border border-dashed border-gray-300 rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50"
                onClick={() => setShowAddCompanyModal(true)}
              >
                <div className="mx-auto h-12 w-12 rounded-full bg-gray-100 flex items-center justify-center">
                  <Plus className="h-6 w-6 text-gray-600" />
                </div>
                <h3 className="mt-2 text-sm font-medium text-gray-900">Adicionar Nova Empresa</h3>
                <p className="mt-1 text-xs text-gray-500">
                  Clique para cadastrar uma nova empresa no sistema
                </p>
              </div>
            </div>
          </div>
        )}
        
        {/* Certificates Tab Content */}
        {activeTab === 'certificates' && (
          <div className="px-4 py-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900">Certificados Digitais</h3>
              
              {selectedCompany ? (
                <div className="flex space-x-3">
                  <button 
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    onClick={() => {}}
                  >
                    <Upload className="h-4 w-4 mr-1" />
                    Importar Certificado
                  </button>
                </div>
              ) : (
                <div className="text-sm text-gray-500">
                  Selecione uma empresa para gerenciar certificados
                </div>
              )}
            </div>
            
            {!selectedCompany ? (
              <div className="text-center py-10">
                <Building2 className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhuma empresa selecionada</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Por favor, selecione uma empresa na aba "Empresas" para visualizar seus certificados.
                </p>
              </div>
            ) : (
              <>
                {companyCertificates.length === 0 ? (
                  <div className="text-center py-10">
                    <Shield className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhum certificado encontrado</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Importe um certificado digital para começar.
                    </p>
                    <div className="mt-6">
                      <button
                        type="button"
                        className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      >
                        <Upload className="mr-2 -ml-1 h-5 w-5" aria-hidden="true" />
                        Importar Certificado
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {companyCertificates.map((certificate) => {
                      // Calculate days until expiration
                      const today = new Date();
                      const expirationDate = new Date(certificate.validTo);
                      const diffTime = expirationDate.getTime() - today.getTime();
                      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                      
                      return (
                        <div 
                          key={certificate.id} 
                          className={`border rounded-md overflow-hidden shadow-sm ${
                            certificate.status === 'valid' && diffDays <= 30
                              ? 'border-yellow-300'
                              : certificate.status === 'valid'
                                ? 'border-green-300'
                                : 'border-red-300'
                          }`}
                        >
                          <div className={`px-4 py-3 ${
                            certificate.status === 'valid' && diffDays <= 30
                              ? 'bg-yellow-50'
                              : certificate.status === 'valid'
                                ? 'bg-green-50'
                                : 'bg-red-50'
                          }`}>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                {getCertificateTypeIcon(certificate.type)}
                                <h4 className="ml-2 text-sm font-medium text-gray-900">
                                  Certificado {certificate.type.toUpperCase()}
                                </h4>
                              </div>
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                getCertificateStatusBadge(certificate.status)
                              }`}>
                                {certificate.status === 'valid' 
                                  ? 'Válido' 
                                  : certificate.status === 'expired'
                                    ? 'Expirado'
                                    : 'Revogado'}
                              </span>
                            </div>
                          </div>
                          
                          <div className="p-4 bg-white">
                            <div className="space-y-3">
                              <div>
                                <div className="text-xs text-gray-500">Serial Number</div>
                                <div className="text-sm font-mono">{certificate.serialNumber}</div>
                              </div>
                              <div>
                                <div className="text-xs text-gray-500">Emissor</div>
                                <div className="text-sm">{certificate.issuer}</div>
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                <div>
                                  <div className="text-xs text-gray-500">Válido De</div>
                                  <div className="text-sm">{formatDate(certificate.validFrom)}</div>
                                </div>
                                <div>
                                  <div className="text-xs text-gray-500">Válido Até</div>
                                  <div className={`text-sm ${
                                    certificate.status === 'valid' && diffDays <= 30
                                      ? 'text-yellow-700 font-medium'
                                      : certificate.status !== 'valid'
                                        ? 'text-red-700 font-medium'
                                        : 'text-gray-900'
                                  }`}>
                                    {formatDate(certificate.validTo)}
                                    {certificate.status === 'valid' && (
                                      <span className="block text-xs">
                                        {diffDays <= 0 
                                          ? 'Expirado' 
                                          : diffDays === 1
                                            ? 'Expira amanhã'
                                            : diffDays <= 30
                                              ? `Expira em ${diffDays} dias`
                                              : ''}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                              
                              <div>
                                <div className="text-xs text-gray-500">Utilizado Para</div>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {certificate.usedFor.map((use, index) => (
                                    <span key={index} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                                      {use.toUpperCase()}
                                    </span>
                                  ))}
                                </div>
                              </div>
                              
                              <div className="flex justify-end space-x-2 pt-2">
                                {certificate.status === 'valid' && (
                                  <button
                                    className="inline-flex items-center px-2 py-1 text-xs border border-transparent rounded text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                                    title="Testar Certificado"
                                  >
                                    <CheckCircle className="h-3 w-3 mr-1" />
                                    Testar
                                  </button>
                                )}
                                <button
                                  className="inline-flex items-center px-2 py-1 text-xs border border-transparent rounded text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                                  title="Download"
                                >
                                  <Download className="h-3 w-3 mr-1" />
                                  Download
                                </button>
                                <button
                                  className="inline-flex items-center px-2 py-1 text-xs border border-transparent rounded text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                                  title="Remover"
                                >
                                  <Trash2 className="h-3 w-3 mr-1" />
                                  Remover
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    
                    {/* Add New Certificate Card */}
                    <div 
                      className="border border-dashed border-gray-300 rounded-md p-4 text-center cursor-pointer hover:bg-gray-50 flex flex-col items-center justify-center"
                      onClick={() => {}}
                    >
                      <div className="h-12 w-12 rounded-full bg-gray-100 flex items-center justify-center mb-3">
                        <Plus className="h-6 w-6 text-gray-600" />
                      </div>
                      <h3 className="text-sm font-medium text-gray-900">Adicionar Novo Certificado</h3>
                      <div className="text-xs mt-1">Importe um certificado A1 ou configure um A3</div>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}
        
        {/* Tax Parameters Tab Content */}
        {activeTab === 'parameters' && (
          <div className="px-4 py-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900">Parâmetros Fiscais e Tributários</h3>
              
              {selectedCompany ? (
                <div className="flex space-x-3">
                  <button 
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    onClick={() => setEditMode(!editMode)}
                  >
                    {editMode ? (
                      <>
                        <Save className="h-4 w-4 mr-1" />
                        Salvar Alterações
                      </>
                    ) : (
                      <>
                        <Edit className="h-4 w-4 mr-1" />
                        Editar Parâmetros
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <div className="text-sm text-gray-500">
                  Selecione uma empresa para gerenciar parâmetros
                </div>
              )}
            </div>
            
            {!selectedCompany ? (
              <div className="text-center py-10">
                <Building2 className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhuma empresa selecionada</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Por favor, selecione uma empresa na aba "Empresas" para visualizar seus parâmetros fiscais.
                </p>
              </div>
            ) : companyTaxParameters.length === 0 ? (
              <div className="text-center py-10">
                <Settings className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhum parâmetro configurado</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Configure os parâmetros fiscais e tributários para esta empresa.
                </p>
                <div className="mt-6">
                  <button
                    type="button"
                    className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    <Plus className="mr-2 -ml-1 h-5 w-5" aria-hidden="true" />
                    Configurar Parâmetros
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {companyTaxParameters.map((params) => (
                  <div key={params.id} className="border border-gray-200 rounded-md overflow-hidden shadow-sm">
                    <div className="bg-blue-50 px-4 py-3 border-b border-blue-100">
                      <div className="flex items-center">
                        <Settings className="h-5 w-5 text-blue-600 mr-2" />
                        <h4 className="text-sm font-medium text-gray-900">
                          Parâmetros Fiscais {params.year}
                        </h4>
                      </div>
                    </div>
                    
                    <div className="p-4 bg-white">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h5 className="text-sm font-medium text-gray-900 mb-3">Alíquotas de Impostos</h5>
                          <div className="bg-gray-50 rounded-md p-3 space-y-3">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label htmlFor="icmsTaxRate" className="block text-xs text-gray-500">ICMS (%)</label>
                                {editMode ? (
                                  <input
                                    id="icmsTaxRate"
                                    name="icmsTaxRate"
                                    value={params.icmsTaxRate}
                                    onChange={() => {}}
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    max="100"
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                  />
                                ) : (
                                  <div className="text-sm mt-1">{params.icmsTaxRate}%</div>
                                )}
                              </div>
                              
                              <div>
                                <label htmlFor="pisRate" className="block text-xs text-gray-500">PIS (%)</label>
                                {editMode ? (
                                  <input
                                    id="pisRate"
                                    name="pisRate"
                                    value={params.pisRate}
                                    onChange={() => {}}
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    max="100"
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                  />
                                ) : (
                                  <div className="text-sm mt-1">{params.pisRate}%</div>
                                )}
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label htmlFor="cofinsRate" className="block text-xs text-gray-500">COFINS (%)</label>
                                {editMode ? (
                                  <input
                                    id="cofinsRate"
                                    name="cofinsRate"
                                    value={params.cofinsRate}
                                    onChange={() => {}}
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    max="100"
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                  />
                                ) : (
                                  <div className="text-sm mt-1">{params.cofinsRate}%</div>
                                )}
                              </div>
                              
                              <div>
                                <label htmlFor="issRate" className="block text-xs text-gray-500">ISS (%)</label>
                                {editMode ? (
                                  <input
                                    id="issRate"
                                    name="issRate"
                                    value={params.issRate}
                                    onChange={() => {}}
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    max="100"
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                  />
                                ) : (
                                  <div className="text-sm mt-1">{params.issRate}%</div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h5 className="text-sm font-medium text-gray-900 mb-3">Configurações de IPI por NCM</h5>
                          <div className="bg-gray-50 rounded-md p-3">
                            {params.ipiRates.length > 0 ? (
                              <div className="space-y-2">
                                {params.ipiRates.map((ipiRate, index) => (
                                  <div key={index} className="flex items-center justify-between">
                                    <div>
                                      <span className="text-sm font-medium">NCM: {ipiRate.ncm}</span>
                                    </div>
                                    {editMode ? (
                                      <div className="flex items-center">
                                        <input
                                          type="number"
                                          step="0.01"
                                          defaultValue={ipiRate.rate}
                                          className="w-20 border border-gray-300 rounded-md shadow-sm py-1 px-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                        />
                                        <span className="ml-1 text-sm">%</span>
                                      </div>
                                    ) : (
                                      <div className="text-sm">{ipiRate.rate}%</div>
                                    )}
                                  </div>
                                ))}
                                
                                {editMode && (
                                  <button
                                    className="mt-2 inline-flex items-center px-2.5 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                                  >
                                    <Plus className="h-3 w-3 mr-1" />
                                    Adicionar NCM
                                  </button>
                                )}
                              </div>
                            ) : (
                              <div className="text-center py-3 text-sm text-gray-500">
                                Nenhuma alíquota de IPI configurada
                                {editMode && (
                                  <div className="mt-2">
                                    <button
                                      className="inline-flex items-center px-2.5 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                                    >
                                      <Plus className="h-3 w-3 mr-1" />
                                      Adicionar Alíquota
                                    </button>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                          
                          <div className="mt-4">
                            <h5 className="text-sm font-medium text-gray-900 mb-3">Informações Adicionais</h5>
                            <div className="bg-gray-50 rounded-md p-3">
                              <div className="space-y-3">
                                <div>
                                  <div className="text-xs text-gray-500">Última Atualização</div>
                                  <div className="text-sm">{formatDate(params.updatedAt || params.createdAt)}</div>
                                </div>
                                <div>
                                  <div className="text-xs text-gray-500">Responsável</div>
                                  <div className="text-sm">ID: {params.updatedBy || params.createdBy}</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add New Company Modal */}
      <Dialog open={showAddCompanyModal} onOpenChange={setShowAddCompanyModal}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle>Adicionar Nova Empresa</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 gap-6 py-4 max-h-[70vh] overflow-y-auto">
            {/* Company Basic Information */}
            <div>
              <h3 className="text-lg font-medium leading-6 text-gray-900">Informações Básicas</h3>
              <div className="mt-2 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="companyName">Razão Social*</Label>
                  <Input 
                    id="companyName"
                    name="companyName"
                    value={newCompanyForm.companyName}
                    onChange={handleInputChange}
                    className={formErrors.companyName ? "border-red-300" : ""}
                  />
                  {formErrors.companyName && (
                    <p className="mt-1 text-xs text-red-600">{formErrors.companyName}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="tradeName">Nome Fantasia*</Label>
                  <Input 
                    id="tradeName"
                    name="tradeName"
                    value={newCompanyForm.tradeName}
                    onChange={handleInputChange}
                    className={formErrors.tradeName ? "border-red-300" : ""}
                  />
                  {formErrors.tradeName && (
                    <p className="mt-1 text-xs text-red-600">{formErrors.tradeName}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="cnpj">CNPJ*</Label>
                  <Input 
                    id="cnpj"
                    name="cnpj"
                    value={newCompanyForm.cnpj}
                    onChange={handleInputChange}
                    placeholder="00.000.000/0000-00"
                    className={formErrors.cnpj ? "border-red-300" : ""}
                  />
                  {formErrors.cnpj && (
                    <p className="mt-1 text-xs text-red-600">{formErrors.cnpj}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="stateRegistration">Inscrição Estadual</Label>
                  <Input 
                    id="stateRegistration"
                    name="stateRegistration"
                    value={newCompanyForm.stateRegistration}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="municipalRegistration">Inscrição Municipal</Label>
                  <Input 
                    id="municipalRegistration"
                    name="municipalRegistration"
                    value={newCompanyForm.municipalRegistration}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="openingDate">Data de Abertura*</Label>
                  <Input 
                    id="openingDate"
                    name="openingDate"
                    type="date"
                    value={newCompanyForm.openingDate}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="taxRegime">Regime Tributário*</Label>
                  <select
                    id="taxRegime"
                    name="taxRegime"
                    value={newCompanyForm.taxRegime}
                    onChange={handleInputChange}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  >
                    <option value="simples">Simples Nacional</option>
                    <option value="presumido">Lucro Presumido</option>
                    <option value="real">Lucro Real</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="status">Status*</Label>
                  <select
                    id="status"
                    name="status"
                    value={newCompanyForm.status}
                    onChange={handleInputChange}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  >
                    <option value="active">Ativo</option>
                    <option value="inactive">Inativo</option>
                    <option value="suspended">Suspenso</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Address Information */}
            <div>
              <h3 className="text-lg font-medium leading-6 text-gray-900">Endereço</h3>
              <div className="mt-2 grid grid-cols-1 gap-4 sm:grid-cols-6">
                <div className="sm:col-span-4">
                  <Label htmlFor="address.street">Logradouro*</Label>
                  <Input 
                    id="address.street"
                    name="address.street"
                    value={newCompanyForm.address.street}
                    onChange={handleInputChange}
                    className={formErrors["address.street"] ? "border-red-300" : ""}
                  />
                  {formErrors["address.street"] && (
                    <p className="mt-1 text-xs text-red-600">{formErrors["address.street"]}</p>
                  )}
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="address.number">Número*</Label>
                  <Input 
                    id="address.number"
                    name="address.number"
                    value={newCompanyForm.address.number}
                    onChange={handleInputChange}
                    className={formErrors["address.number"] ? "border-red-300" : ""}
                  />
                  {formErrors["address.number"] && (
                    <p className="mt-1 text-xs text-red-600">{formErrors["address.number"]}</p>
                  )}
                </div>
                <div className="sm:col-span-3">
                  <Label htmlFor="address.complement">Complemento</Label>
                  <Input 
                    id="address.complement"
                    name="address.complement"
                    value={newCompanyForm.address.complement}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="sm:col-span-3">
                  <Label htmlFor="address.district">Bairro*</Label>
                  <Input 
                    id="address.district"
                    name="address.district"
                    value={newCompanyForm.address.district}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="address.zipCode">CEP*</Label>
                  <Input 
                    id="address.zipCode"
                    name="address.zipCode"
                    value={newCompanyForm.address.zipCode}
                    onChange={handleInputChange}
                    placeholder="00000-000"
                    className={formErrors["address.zipCode"] ? "border-red-300" : ""}
                  />
                  {formErrors["address.zipCode"] && (
                    <p className="mt-1 text-xs text-red-600">{formErrors["address.zipCode"]}</p>
                  )}
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="address.city">Cidade*</Label>
                  <Input 
                    id="address.city"
                    name="address.city"
                    value={newCompanyForm.address.city}
                    onChange={handleInputChange}
                    className={formErrors["address.city"] ? "border-red-300" : ""}
                  />
                  {formErrors["address.city"] && (
                    <p className="mt-1 text-xs text-red-600">{formErrors["address.city"]}</p>
                  )}
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="address.state">Estado*</Label>
                  <select
                    id="address.state"
                    name="address.state"
                    value={newCompanyForm.address.state}
                    onChange={handleInputChange}
                    className={`mt-1 block w-full pl-3 pr-10 py-2 text-base border ${formErrors["address.state"] ? "border-red-300" : "border-gray-300"} focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md`}
                  >
                    <option value="">Selecione...</option>
                    <option value="AC">Acre</option>
                    <option value="AL">Alagoas</option>
                    <option value="AP">Amapá</option>
                    <option value="AM">Amazonas</option>
                    <option value="BA">Bahia</option>
                    <option value="CE">Ceará</option>
                    <option value="DF">Distrito Federal</option>
                    <option value="ES">Espírito Santo</option>
                    <option value="GO">Goiás</option>
                    <option value="MA">Maranhão</option>
                    <option value="MT">Mato Grosso</option>
                    <option value="MS">Mato Grosso do Sul</option>
                    <option value="MG">Minas Gerais</option>
                    <option value="PA">Pará</option>
                    <option value="PB">Paraíba</option>
                    <option value="PR">Paraná</option>
                    <option value="PE">Pernambuco</option>
                    <option value="PI">Piauí</option>
                    <option value="RJ">Rio de Janeiro</option>
                    <option value="RN">Rio Grande do Norte</option>
                    <option value="RS">Rio Grande do Sul</option>
                    <option value="RO">Rondônia</option>
                    <option value="RR">Roraima</option>
                    <option value="SC">Santa Catarina</option>
                    <option value="SP">São Paulo</option>
                    <option value="SE">Sergipe</option>
                    <option value="TO">Tocantins</option>
                  </select>
                  {formErrors["address.state"] && (
                    <p className="mt-1 text-xs text-red-600">{formErrors["address.state"]}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div>
              <h3 className="text-lg font-medium leading-6 text-gray-900">Contato</h3>
              <div className="mt-2 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="phone">Telefone*</Label>
                  <Input 
                    id="phone"
                    name="phone"
                    value={newCompanyForm.phone}
                    onChange={handleInputChange}
                    placeholder="(00) 0000-0000"
                    className={formErrors.phone ? "border-red-300" : ""}
                  />
                  {formErrors.phone && (
                    <p className="mt-1 text-xs text-red-600">{formErrors.phone}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="email">Email*</Label>
                  <Input 
                    id="email"
                    name="email"
                    type="email"
                    value={newCompanyForm.email}
                    onChange={handleInputChange}
                    className={formErrors.email ? "border-red-300" : ""}
                  />
                  {formErrors.email && (
                    <p className="mt-1 text-xs text-red-600">{formErrors.email}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Commercial Information */}
            <div>
              <h3 className="text-lg font-medium leading-6 text-gray-900">Informações Comerciais</h3>
              <div className="mt-2 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="economicActivity">Atividade Econômica*</Label>
                  <Input 
                    id="economicActivity"
                    name="economicActivity"
                    value={newCompanyForm.economicActivity}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="cnae">CNAE Principal*</Label>
                  <Input 
                    id="cnae"
                    name="cnae"
                    value={newCompanyForm.cnae}
                    onChange={handleInputChange}
                    placeholder="00.00-0-00"
                  />
                </div>
                <div>
                  <Label htmlFor="accountingResponsible">Contador Responsável</Label>
                  <Input 
                    id="accountingResponsible"
                    name="accountingResponsible"
                    value={newCompanyForm.accountingResponsible}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddCompanyModal(false)}>Cancelar</Button>
            <Button onClick={handleAddCompany}>Adicionar Empresa</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Settings Modal */}
      <Dialog open={showSettingsModal} onOpenChange={setShowSettingsModal}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Configurações da Empresa</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <h3 className="text-sm font-medium text-gray-700">Configurações Gerais</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="companyStatus">Status da Empresa</Label>
                <select
                  id="companyStatus"
                  name="companyStatus"
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  defaultValue="active"
                >
                  <option value="active">Ativo</option>
                  <option value="inactive">Inativo</option>
                  <option value="suspended">Suspenso</option>
                </select>
              </div>
              
              <div>
                <Label htmlFor="fiscalEnvironment">Ambiente Fiscal</Label>
                <select
                  id="fiscalEnvironment"
                  name="fiscalEnvironment"
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  defaultValue="test"
                >
                  <option value="test">Homologação (Testes)</option>
                  <option value="production">Produção</option>
                </select>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <h3 className="text-sm font-medium text-gray-700">Configurações de Documentos</h3>
              <div className="mt-4 space-y-4">
                <div className="flex items-center">
                  <input
                    id="autoGenerateInvoice"
                    name="autoGenerateInvoice"
                    type="checkbox"
                    defaultChecked
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                  />
                  <label htmlFor="autoGenerateInvoice" className="ml-2 block text-sm text-gray-900">
                    Gerar NF-e automaticamente para cada venda
                  </label>
                </div>
                
                <div className="flex items-center">
                  <input
                    id="useDigitalSignature"
                    name="useDigitalSignature"
                    type="checkbox"
                    defaultChecked
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                  />
                  <label htmlFor="useDigitalSignature" className="ml-2 block text-sm text-gray-900">
                    Usar assinatura digital nos documentos
                  </label>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <h3 className="text-sm font-medium text-gray-700">Numeração de Documentos</h3>
              <div className="mt-4 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nfeSeries">Série NF-e</Label>
                    <Input id="nfeSeries" name="nfeSeries" defaultValue="1" />
                  </div>
                  <div>
                    <Label htmlFor="nfceSerires">Série NFC-e</Label>
                    <Input id="nfceSerires" name="nfceSerires" defaultValue="2" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSettingsModal(false)}>Cancelar</Button>
            <Button onClick={handleSaveSettings}>Salvar Configurações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Logo Management Modal */}
      <Dialog open={showLogoModal} onOpenChange={setShowLogoModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Gerenciamento de Logo</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="h-32 w-64 bg-gray-100 rounded-md flex items-center justify-center overflow-hidden border-2 border-dashed border-gray-300">
                {companyLogo ? (
                  <img 
                    src={companyLogo} 
                    alt="Logo Preview" 
                    className="max-h-full max-w-full object-contain"
                  />
                ) : (
                  <div className="text-center">
                    <Camera className="mx-auto h-12 w-12 text-gray-400" />
                    <span className="mt-2 block text-sm text-gray-500">
                      Nenhuma imagem selecionada
                    </span>
                  </div>
                )}
              </div>
              
              <div className="text-sm text-gray-500 text-center">
                Tamanho recomendado: 200x60px (PNG, JPG)
                <br />
                Tamanho máximo: 2MB
              </div>
              
              <label htmlFor="logo-upload" className="w-full">
                <div className="w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:text-sm cursor-pointer">
                  <Upload className="h-5 w-5 mr-2" />
                  {companyLogo ? 'Trocar Logo' : 'Selecionar Logo'}
                </div>
                <input 
                  id="logo-upload" 
                  name="logo" 
                  type="file" 
                  accept="image/png,image/jpeg" 
                  className="sr-only"
                  onChange={handleLogoFileChange}
                />
              </label>
              
              {companyLogo && (
                <Button 
                  variant="outline" 
                  className="w-full border-red-300 text-red-600 hover:bg-red-50"
                  onClick={handleRemoveLogo}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Remover Logo
                </Button>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLogoModal(false)}>Cancelar</Button>
            <Button 
              onClick={handleUploadLogo}
              disabled={!logoFile && !companyLogo}
            >
              <Save className="h-4 w-4 mr-2" />
              Salvar Logo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar Ação</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-gray-500">{confirmMessage}</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={() => confirmAction()}>
              Confirmar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};