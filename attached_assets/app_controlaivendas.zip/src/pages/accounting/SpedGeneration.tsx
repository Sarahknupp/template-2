import React, { useState } from 'react';
import { FileBarChart, Download, Calendar, ChevronDown, ArrowUpDown, CheckCircle, AlertTriangle, XCircle, ArrowRight, Loader, Settings, FileUp } from 'lucide-react';
import { mockSpedFiles } from '../../data/mockAccountingData';

export const SpedGeneration: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [selectedMonth, setSelectedMonth] = useState<string>('202310');
  const [sortField, setSortField] = useState<string>('reference');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [showValidationModal, setShowValidationModal] = useState(false);
  const [selectedFile, setSelectedFile] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  
  // Format date
  const formatDate = (date: Date): string => {
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  // Format file size
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };
  
  // Filter SPED files
  const filteredFiles = mockSpedFiles.filter(file => {
    const matchesSearch = searchTerm === '' || 
                        file.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        file.reference.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || file.type === filterType;
    
    return matchesSearch && matchesType;
  });
  
  // Sort SPED files
  const sortedFiles = [...filteredFiles].sort((a, b) => {
    if (sortField === 'reference') {
      return sortDirection === 'asc'
        ? a.reference.localeCompare(b.reference)
        : b.reference.localeCompare(a.reference);
    } else if (sortField === 'type') {
      return sortDirection === 'asc'
        ? a.type.localeCompare(b.type)
        : b.type.localeCompare(a.type);
    } else if (sortField === 'generationDate') {
      return sortDirection === 'asc'
        ? a.generationDate.getTime() - b.generationDate.getTime()
        : b.generationDate.getTime() - a.generationDate.getTime();
    } else if (sortField === 'status') {
      return sortDirection === 'asc'
        ? a.status.localeCompare(b.status)
        : b.status.localeCompare(a.status);
    }
    return 0;
  });
  
  const handleSort = (field: string) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };
  
  const handleViewValidation = (file: any) => {
    setSelectedFile(file);
    setShowValidationModal(true);
  };
  
  const handleGenerate = () => {
    setIsGenerating(true);
    setGenerationProgress(0);
    
    // Simulate file generation process
    const timer = setInterval(() => {
      setGenerationProgress(oldProgress => {
        const newProgress = oldProgress + 10;
        if (newProgress >= 100) {
          clearInterval(timer);
          setTimeout(() => {
            setIsGenerating(false);
          }, 500);
          return 100;
        }
        return newProgress;
      });
    }, 500);
  };
  
  // Get status badge style
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'transmitted':
        return 'bg-green-100 text-green-800';
      case 'generated':
        return 'bg-blue-100 text-blue-800';
      case 'generating':
        return 'bg-yellow-100 text-yellow-800';
      case 'validated':
        return 'bg-indigo-100 text-indigo-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900 flex items-center">
          <FileBarChart className="h-6 w-6 mr-2 text-gray-700" />
          Geração SPED
        </h1>
        
        <div className="flex space-x-3">
          <div className="relative">
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="block pl-10 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
            >
              <option value="202310">Outubro/2023</option>
              <option value="202309">Setembro/2023</option>
              <option value="202308">Agosto/2023</option>
              <option value="202307">Julho/2023</option>
            </select>
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Calendar className="h-4 w-4 text-gray-400" />
            </div>
          </div>
          
          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
              isGenerating ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            {isGenerating ? (
              <Loader className="h-4 w-4 mr-1 animate-spin" />
            ) : (
              <FileBarChart className="h-4 w-4 mr-1" />
            )}
            Gerar Arquivos SPED
          </button>
        </div>
      </div>
      
      {isGenerating && (
        <div className="bg-white shadow rounded-lg p-4 mb-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <Loader className="h-5 w-5 text-indigo-600 animate-spin mr-2" />
              <span className="text-sm font-medium text-gray-900">
                Gerando arquivos SPED para {selectedMonth.slice(0, 4)}/{selectedMonth.slice(4, 6)}
              </span>
            </div>
            <span className="text-sm text-gray-500">{generationProgress}% concluído</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300" style={{ width: `${generationProgress}%` }}></div>
          </div>
          <div className="mt-2 grid grid-cols-3 gap-2 text-sm">
            <div className={`px-3 py-2 rounded ${generationProgress >= 40 ? 'bg-green-50 text-green-800' : 'bg-gray-50 text-gray-500'}`}>
              <div className="flex items-center">
                {generationProgress >= 40 ? (
                  <CheckCircle className="h-4 w-4 mr-1" />
                ) : (
                  <Loader className={`h-4 w-4 mr-1 ${generationProgress > 0 ? 'animate-spin text-indigo-500' : ''}`} />
                )}
                <span>SPED Fiscal</span>
              </div>
            </div>
            <div className={`px-3 py-2 rounded ${generationProgress >= 80 ? 'bg-green-50 text-green-800' : 'bg-gray-50 text-gray-500'}`}>
              <div className="flex items-center">
                {generationProgress >= 80 ? (
                  <CheckCircle className="h-4 w-4 mr-1" />
                ) : (
                  <Loader className={`h-4 w-4 mr-1 ${generationProgress >= 40 ? 'animate-spin text-indigo-500' : ''}`} />
                )}
                <span>SPED Contribuições</span>
              </div>
            </div>
            <div className={`px-3 py-2 rounded ${generationProgress >= 100 ? 'bg-green-50 text-green-800' : 'bg-gray-50 text-gray-500'}`}>
              <div className="flex items-center">
                {generationProgress >= 100 ? (
                  <CheckCircle className="h-4 w-4 mr-1" />
                ) : (
                  <Loader className={`h-4 w-4 mr-1 ${generationProgress >= 80 ? 'animate-spin text-indigo-500' : ''}`} />
                )}
                <span>ECD Contábil</span>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* SPED Files Table */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Arquivos SPED
            </h3>
            
            <div className="mt-3 sm:mt-0 flex flex-wrap space-y-2 sm:space-y-0 sm:space-x-2">
              <div className="relative">
                <input
                  type="text"
                  className="block w-full pl-3 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Pesquisar arquivos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="relative">
                <select
                  className="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                >
                  <option value="all">Todos os Tipos</option>
                  <option value="fiscal">SPED Fiscal</option>
                  <option value="contributions">SPED Contribuições</option>
                  <option value="accounting">ECD Contábil</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                  <ChevronDown className="h-4 w-4 text-gray-400" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer" onClick={() => handleSort('reference')}>
                  <div className="flex items-center">
                    Referência
                    {sortField === 'reference' && (
                      <ArrowUpDown className="ml-1 h-4 w-4 text-gray-400" />
                    )}
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer" onClick={() => handleSort('type')}>
                  <div className="flex items-center">
                    Tipo
                    {sortField === 'type' && (
                      <ArrowUpDown className="ml-1 h-4 w-4 text-gray-400" />
                    )}
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer" onClick={() => handleSort('generationDate')}>
                  <div className="flex items-center">
                    Data Geração
                    {sortField === 'generationDate' && (
                      <ArrowUpDown className="ml-1 h-4 w-4 text-gray-400" />
                    )}
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Arquivo
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer" onClick={() => handleSort('status')}>
                  <div className="flex items-center">
                    Status
                    {sortField === 'status' && (
                      <ArrowUpDown className="ml-1 h-4 w-4 text-gray-400" />
                    )}
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sortedFiles.map((file) => (
                <tr key={file.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {file.reference.slice(0, 4)}/{file.reference.slice(5, 7) || 'Anual'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      file.type === 'fiscal' 
                        ? 'bg-blue-100 text-blue-800' 
                        : file.type === 'contributions'
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-green-100 text-green-800'
                    }`}>
                      {file.type === 'fiscal' 
                        ? 'SPED Fiscal' 
                        : file.type === 'contributions'
                          ? 'SPED Contribuições'
                          : 'ECD Contábil'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(file.generationDate)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 truncate max-w-xs">{file.fileName}</div>
                    <div className="text-xs text-gray-500">{formatFileSize(file.fileSize)}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusBadge(file.status)}`}>
                      {file.status === 'transmitted' 
                        ? 'Transmitido' 
                        : file.status === 'generated'
                          ? 'Gerado'
                          : file.status === 'generating'
                            ? 'Gerando'
                            : file.status === 'validated'
                              ? 'Validado'
                              : 'Erro'}
                    </span>
                    
                    {file.status === 'transmitted' && file.protocol && (
                      <div className="text-xs text-gray-500 mt-1">
                        Protocolo: {file.protocol}
                      </div>
                    )}
                    
                    {file.status === 'error' && file.errorMessage && (
                      <div className="text-xs text-red-500 mt-1">
                        {file.errorMessage}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                      <button
                        className="text-indigo-600 hover:text-indigo-900"
                        title="Download"
                        disabled={file.status !== 'generated' && file.status !== 'validated' && file.status !== 'transmitted'}
                      >
                        <Download className="h-5 w-5" />
                      </button>
                      
                      {(file.status === 'generated' || file.status === 'validated') && (
                        <button
                          className="text-green-600 hover:text-green-900"
                          title="Transmitir"
                        >
                          <ArrowRight className="h-5 w-5" />
                        </button>
                      )}
                      
                      {file.validationMessages && file.validationMessages.length > 0 && (
                        <button
                          className={`${file.validationMessages.some(m => m.type === 'error') ? 'text-red-600 hover:text-red-900' : 'text-amber-600 hover:text-amber-900'}`}
                          title="Ver Validação"
                          onClick={() => handleViewValidation(file)}
                        >
                          {file.validationMessages.some(m => m.type === 'error') ? (
                            <XCircle className="h-5 w-5" />
                          ) : (
                            <AlertTriangle className="h-5 w-5" />
                          )}
                        </button>
                      )}
                      
                      <button className="text-gray-600 hover:text-gray-900" title="Configurações">
                        <Settings className="h-5 w-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {sortedFiles.length === 0 && (
            <div className="text-center py-10">
              <FileBarChart className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhum arquivo SPED encontrado</h3>
              <p className="mt-1 text-sm text-gray-500">
                Tente ajustar sua pesquisa ou filtros.
              </p>
              <div className="mt-6">
                <button
                  type="button"
                  onClick={handleGenerate}
                  className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  <FileBarChart className="mr-2 -ml-1 h-5 w-5" aria-hidden="true" />
                  Gerar Novo Arquivo SPED
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* SPED Generation Settings */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg leading-6 font-medium text-gray-900 flex items-center">
            <Settings className="h-5 w-5 mr-2 text-gray-700" />
            Configurações de Geração SPED
          </h3>
        </div>
        <div className="px-4 py-5 sm:p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* SPED Fiscal */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center mb-3">
                <FileBarChart className="h-5 w-5 text-blue-600 mr-2" />
                <h4 className="text-base font-medium text-blue-800">SPED Fiscal (EFD ICMS/IPI)</h4>
              </div>
              <div className="text-sm text-blue-700 mb-4">
                <p>Geração de arquivos de escrituração fiscal digital ICMS/IPI para empresas contribuintes do ICMS.</p>
              </div>
              
              <div className="space-y-3 mb-4">
                <div className="flex items-center">
                  <input
                    id="includeBlocoK"
                    name="includeBlocoK"
                    type="checkbox"
                    checked
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor="includeBlocoK" className="ml-2 block text-sm text-blue-700">
                    Incluir Bloco K (Controle de Produção)
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="includeBloco0190"
                    name="includeBloco0190"
                    type="checkbox"
                    checked
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor="includeBloco0190" className="ml-2 block text-sm text-blue-700">
                    Incluir Registro 0190 (Unidades de Medida)
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="validateBeforeGeneration"
                    name="validateBeforeGeneration"
                    type="checkbox"
                    checked
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor="validateBeforeGeneration" className="ml-2 block text-sm text-blue-700">
                    Validar antes da geração
                  </label>
                </div>
              </div>
              
              <button className="w-full inline-flex justify-center items-center px-4 py-2 border border-blue-300 shadow-sm text-sm font-medium rounded-md text-blue-700 bg-white hover:bg-blue-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                Configurar Layout
              </button>
            </div>
            
            {/* SPED Contribuições */}
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
              <div className="flex items-center mb-3">
                <FileBarChart className="h-5 w-5 text-purple-600 mr-2" />
                <h4 className="text-base font-medium text-purple-800">SPED Contribuições (EFD PIS/COFINS)</h4>
              </div>
              <div className="text-sm text-purple-700 mb-4">
                <p>Escrituração fiscal digital para apuração das contribuições de PIS/PASEP e COFINS.</p>
              </div>
              
              <div className="space-y-3 mb-4">
                <div className="flex items-center">
                  <input
                    id="consolidateRevenues"
                    name="consolidateRevenues"
                    type="checkbox"
                    checked
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                  />
                  <label htmlFor="consolidateRevenues" className="ml-2 block text-sm text-purple-700">
                    Consolidar Receitas por CST
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="detailCredits"
                    name="detailCredits"
                    type="checkbox"
                    checked
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                  />
                  <label htmlFor="detailCredits" className="ml-2 block text-sm text-purple-700">
                    Detalhar Créditos por Natureza
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="includePrevMonths"
                    name="includePrevMonths"
                    type="checkbox"
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                  />
                  <label htmlFor="includePrevMonths" className="ml-2 block text-sm text-purple-700">
                    Incluir Ajustes de Períodos Anteriores
                  </label>
                </div>
              </div>
              
              <button className="w-full inline-flex justify-center items-center px-4 py-2 border border-purple-300 shadow-sm text-sm font-medium rounded-md text-purple-700 bg-white hover:bg-purple-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500">
                Configurar Layout
              </button>
            </div>
            
            {/* ECD Contábil */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center mb-3">
                <FileBarChart className="h-5 w-5 text-green-600 mr-2" />
                <h4 className="text-base font-medium text-green-800">ECD Contábil</h4>
              </div>
              <div className="text-sm text-green-700 mb-4">
                <p>Escrituração contábil digital para substituição dos livros contábeis em versão física.</p>
              </div>
              
              <div className="space-y-3 mb-4">
                <div className="flex items-center">
                  <input
                    id="includeBookI"
                    name="includeBookI"
                    type="checkbox"
                    checked
                    className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                  />
                  <label htmlFor="includeBookI" className="ml-2 block text-sm text-green-700">
                    Incluir Livro Diário
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="includeBookG"
                    name="includeBookG"
                    type="checkbox"
                    checked
                    className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                  />
                  <label htmlFor="includeBookG" className="ml-2 block text-sm text-green-700">
                    Incluir Livro Razão
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="includeBookZ"
                    name="includeBookZ"
                    type="checkbox"
                    checked
                    className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                  />
                  <label htmlFor="includeBookZ" className="ml-2 block text-sm text-green-700">
                    Incluir Demonstrações Contábeis
                  </label>
                </div>
              </div>
              
              <button className="w-full inline-flex justify-center items-center px-4 py-2 border border-green-300 shadow-sm text-sm font-medium rounded-md text-green-700 bg-white hover:bg-green-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                Configurar Layout
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Validation Messages Modal */}
      {showValidationModal && selectedFile && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
            
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <h3 className="text-lg leading-6 font-medium text-gray-900 flex items-center">
                      <AlertTriangle className="h-5 w-5 mr-2 text-amber-500" />
                      Mensagens de Validação
                    </h3>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500 mb-3">
                        Arquivo: {selectedFile.fileName}
                      </p>
                      
                      {selectedFile.validationMessages?.length ? (
                        <div className="max-h-96 overflow-y-auto">
                          <div className="border border-gray-200 rounded-md divide-y divide-gray-200">
                            {selectedFile.validationMessages.map((message: any, index: number) => (
                              <div 
                                key={index} 
                                className={`p-3 ${
                                  message.type === 'error' 
                                    ? 'bg-red-50' 
                                    : message.type === 'warning'
                                      ? 'bg-yellow-50'
                                      : 'bg-blue-50'
                                }`}
                              >
                                <div className="flex items-start">
                                  {message.type === 'error' ? (
                                    <XCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                                  ) : message.type === 'warning' ? (
                                    <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0" />
                                  ) : (
                                    <CheckCircle className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0" />
                                  )}
                                  <div>
                                    <div className={`text-sm font-medium ${
                                      message.type === 'error' 
                                        ? 'text-red-800' 
                                        : message.type === 'warning'
                                          ? 'text-yellow-800'
                                          : 'text-blue-800'
                                    }`}>
                                      {message.message}
                                    </div>
                                    <div className="text-xs mt-1 text-gray-500">
                                      Bloco: {message.block}, Registro: {message.record}, Campo: {message.field}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-4">
                          <CheckCircle className="mx-auto h-10 w-10 text-green-500" />
                          <p className="mt-2 text-sm text-gray-600">
                            Nenhuma mensagem de validação encontrada.
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  onClick={() => setShowValidationModal(false)}
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-indigo-600 text-base font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:ml-3 sm:w-auto sm:text-sm"
                >
                  Fechar
                </button>
                {selectedFile.status === 'error' && (
                  <button
                    type="button"
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    Corrigir e Regenerar
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};