import React, { useState } from 'react';
import { BarChart2, Calendar, TrendingUp, FileText, Download, Printer, Filter, RefreshCw, Search, Clock, Eye, Plus } from 'lucide-react';
import { mockDailySales, mockProductSales } from '../../data/mockData';
import { reportTypes } from './ReportsConfig';
import { ReportViewer } from './ReportViewer';
import { Button } from '../../components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../../components/ui/dialog';
import { ReportScheduleForm } from './ReportScheduleForm';
import { ReportParameters } from '../../types/reports';
import toast from 'react-hot-toast';
import { ReportConfig } from './ReportsConfig';
import { 
  generateBalanceSheet, 
  generateIncomeStatement,
  generateCashFlowStatement,
  generateTrialBalance,
  exportPDF 
} from '../../services/pdfService';

export const Reports: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [dateRange, setDateRange] = useState<'day' | 'week' | 'month' | 'quarter' | 'year'>('month');
  const [searchTerm, setSearchTerm] = useState('');
  const [showReportViewer, setShowReportViewer] = useState(false);
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showScheduleForm, setShowScheduleForm] = useState(false);
  const [showConfigPage, setShowConfigPage] = useState(false);
  
  // Helper to format dates
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      month: 'short',
      day: 'numeric',
    }).format(date);
  };
  
  // Generate dummy data for demo charts
  const salesData = mockDailySales;
  const productData = mockProductSales;
  
  // Find highest values for scaling
  const maxSales = Math.max(...salesData.map(d => d.total));
  const maxRevenue = Math.max(...productData.map(p => p.revenue));
  
  // Filter report types by category and search term
  const filteredReports = reportTypes.filter(report => {
    const matchesCategory = activeCategory === 'all' || report.category === activeCategory;
    const matchesSearch = searchTerm === '' || 
                         report.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         report.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });
  
  const generateReport = (reportId: string) => {
    setIsLoading(true);
    setSelectedReportId(reportId);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setShowReportViewer(true);
    }, 1500);
  };
  
  const scheduleReport = (reportId: string) => {
    setSelectedReportId(reportId);
    setShowScheduleForm(true);
  };
  
  const handleSaveSchedule = (parameters: ReportParameters) => {
    // In a real app, this would be an API call
    console.log('Schedule saved:', { reportId: selectedReportId, parameters });
    toast.success('Relatório agendado com sucesso!');
    setShowScheduleForm(false);
  };
  
  const exportReport = (format: 'pdf' | 'excel' | 'csv') => {
    setIsLoading(true);
    
    try {
      if (format !== 'pdf') {
        toast.error(`Exportação em formato ${format.toUpperCase()} em desenvolvimento.`);
        setIsLoading(false);
        return;
      }
      
      let doc;
      let filename;
      
      switch (selectedReportId) {
        case 'balanco':
          doc = generateBalanceSheet(null, dateRange);
          filename = `balanco_patrimonial_${new Date().toISOString().split('T')[0]}.pdf`;
          break;
          
        case 'dre':
          doc = generateIncomeStatement(null, dateRange);
          filename = `demonstracao_resultado_${new Date().toISOString().split('T')[0]}.pdf`;
          break;
          
        case 'fluxo_caixa':
          doc = generateCashFlowStatement(null, dateRange);
          filename = `fluxo_caixa_${new Date().toISOString().split('T')[0]}.pdf`;
          break;
          
        case 'balancete':
          doc = generateTrialBalance(null, dateRange);
          filename = `balancete_${new Date().toISOString().split('T')[0]}.pdf`;
          break;
          
        default:
          toast.error('Tipo de relatório não suportado');
          setIsLoading(false);
          return;
      }
      
      // Export the PDF
      exportPDF(doc, filename);
      toast.success(`Relatório exportado com sucesso como ${filename}`);
    } catch (error) {
      console.error('Erro ao gerar relatório:', error);
      toast.error('Erro ao gerar o relatório PDF');
    } finally {
      setIsLoading(false);
    }
  };
  
  const printReport = () => {
    toast.success('Enviando relatório para impressão...');
    // In a real app, this would trigger the print dialog
    setTimeout(() => {
      window.print();
    }, 1000);
  };
  
  if (showConfigPage) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-gray-900">Configuração de Relatórios</h1>
          <Button
            variant="outline"
            onClick={() => setShowConfigPage(false)}
          >
            Voltar para Relatórios
          </Button>
        </div>
        
        <ReportConfig />
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900 flex items-center">
          <BarChart2 className="h-6 w-6 mr-2 text-amber-600" />
          Relatórios e Análises
        </h1>
        
        <div className="flex space-x-3">
          <div className="relative">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value as any)}
              className="block pl-10 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm rounded-md"
            >
              <option value="day">Hoje</option>
              <option value="week">Esta Semana</option>
              <option value="month">Este Mês</option>
              <option value="quarter">Este Trimestre</option>
              <option value="year">Este Ano</option>
              <option value="custom">Período Personalizado</option>
            </select>
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Calendar className="h-4 w-4 text-gray-400" />
            </div>
          </div>
          
          <Button
            variant="outline"
            onClick={() => setShowConfigPage(true)}
          >
            <BarChart2 className="h-4 w-4 mr-1" />
            Configurações
          </Button>
        </div>
      </div>
      
      {/* Search and Categories */}
      <div className="bg-white shadow rounded-lg p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="md:w-1/3">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                placeholder="Pesquisar relatórios..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <button
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                activeCategory === 'all'
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              onClick={() => setActiveCategory('all')}
            >
              Todos
            </button>
            <button
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                activeCategory === 'financial'
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              onClick={() => setActiveCategory('financial')}
            >
              Financeiros
            </button>
            <button
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                activeCategory === 'inventory'
                  ? 'bg-blue-100 text-blue-800'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              onClick={() => setActiveCategory('inventory')}
            >
              Estoque
            </button>
            <button
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                activeCategory === 'production'
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              onClick={() => setActiveCategory('production')}
            >
              Produção
            </button>
            <button
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                activeCategory === 'sales'
                  ? 'bg-purple-100 text-purple-800'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              onClick={() => setActiveCategory('sales')}
            >
              Vendas
            </button>
            <button
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                activeCategory === 'operations'
                  ? 'bg-indigo-100 text-indigo-800'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              onClick={() => setActiveCategory('operations')}
            >
              Operacional
            </button>
            <button
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                activeCategory === 'administrative'
                  ? 'bg-gray-100 text-gray-800'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              onClick={() => setActiveCategory('administrative')}
            >
              Administrativo
            </button>
            <button
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                activeCategory === 'fiscal'
                  ? 'bg-orange-100 text-orange-800'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              onClick={() => setActiveCategory('fiscal')}
            >
              Fiscal
            </button>
          </div>
        </div>
      </div>
      
      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {filteredReports.map((report) => (
          <div 
            key={report.id} 
            className="bg-white shadow rounded-lg overflow-hidden hover:shadow-md transition-shadow border border-gray-200"
          >
            <div className={`p-4 border-b ${
              report.category === 'financial' ? 'bg-green-50 border-green-100' :
              report.category === 'inventory' ? 'bg-blue-50 border-blue-100' :
              report.category === 'production' ? 'bg-amber-50 border-amber-100' :
              report.category === 'sales' ? 'bg-purple-50 border-purple-100' :
              report.category === 'operations' ? 'bg-indigo-50 border-indigo-100' :
              report.category === 'administrative' ? 'bg-gray-50 border-gray-100' :
              'bg-orange-50 border-orange-100'
            }`}>
              <h3 className="text-lg font-medium text-gray-900">{report.name}</h3>
              <p className="mt-1 text-sm text-gray-500">{report.description}</p>
            </div>
            
            <div className="p-4 flex flex-col">
              <div className="flex flex-wrap gap-2 mb-4">
                {report.formats.map(format => (
                  <span key={format} className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-gray-100 text-gray-700">
                    {format.toUpperCase()}
                  </span>
                ))}
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-blue-100 text-blue-700">
                  <Clock className="h-3 w-3 mr-1" />
                  {report.availableFrequencies.includes('daily') ? 'Diário' : 
                   report.availableFrequencies.includes('weekly') ? 'Semanal' : 
                   report.availableFrequencies.includes('monthly') ? 'Mensal' : 'Personalizado'}
                </span>
              </div>
              <div className="flex gap-2 mt-auto">
                <Button 
                  variant="outline"
                  className="flex-1 flex items-center justify-center"
                  onClick={() => scheduleReport(report.id)}
                >
                  <Clock className="h-4 w-4 mr-1" />
                  Agendar
                </Button>
                <Button 
                  className="flex-1 flex items-center justify-center"
                  onClick={() => generateReport(report.id)}
                >
                  <Eye className="h-4 w-4 mr-1" />
                  Visualizar
                </Button>
              </div>
            </div>
          </div>
        ))}
        
        {/* Add Custom Report Card */}
        <div 
          className="bg-white shadow rounded-lg border border-dashed border-gray-300 overflow-hidden hover:border-amber-500 hover:shadow-md transition-all cursor-pointer p-6 flex flex-col items-center justify-center text-center"
          onClick={() => setShowConfigPage(true)}
        >
          <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center mb-3">
            <Plus className="h-6 w-6 text-amber-600" />
          </div>
          <h3 className="text-lg font-medium text-gray-900">Configurar Novo Relatório</h3>
          <p className="mt-2 text-sm text-gray-500">
            Crie um relatório personalizado com os campos e filtros de sua escolha.
          </p>
        </div>
      </div>
      
      {filteredReports.length === 0 && searchTerm && (
        <div className="text-center bg-white p-8 rounded-lg shadow">
          <BarChart2 className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-lg font-medium text-gray-900">Nenhum relatório encontrado</h3>
          <p className="mt-2 text-gray-500">
            Nenhum relatório correspondente à sua pesquisa "{searchTerm}".
          </p>
        </div>
      )}
      
      {/* Recent & Favorite Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Relatórios Recentes</h3>
          </div>
          <div className="divide-y divide-gray-200">
            <div className="p-4 hover:bg-gray-50 cursor-pointer" onClick={() => generateReport('balanco')}>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-10 w-10 rounded-md bg-green-100 flex items-center justify-center">
                    <FileText className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <h4 className="text-sm font-medium text-gray-900">Balanço Patrimonial</h4>
                    <p className="text-xs text-gray-500">Gerado em 05/11/2023 10:45</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <button
                    className="p-1 rounded-full text-gray-400 hover:text-gray-500"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedReportId('balanco');
                      exportReport('pdf');
                    }}
                  >
                    <Download className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
            <div className="p-4 hover:bg-gray-50 cursor-pointer" onClick={() => generateReport('dre')}>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-10 w-10 rounded-md bg-blue-100 flex items-center justify-center">
                    <FileText className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <h4 className="text-sm font-medium text-gray-900">Demonstração do Resultado</h4>
                    <p className="text-xs text-gray-500">Gerado em 04/11/2023 16:20</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <button
                    className="p-1 rounded-full text-gray-400 hover:text-gray-500"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedReportId('dre');
                      exportReport('pdf');
                    }}
                  >
                    <Download className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
            <div className="p-4 hover:bg-gray-50 cursor-pointer" onClick={() => generateReport('fluxo_caixa')}>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-10 w-10 rounded-md bg-amber-100 flex items-center justify-center">
                    <FileText className="h-6 w-6 text-amber-600" />
                  </div>
                  <div className="ml-4">
                    <h4 className="text-sm font-medium text-gray-900">Fluxo de Caixa</h4>
                    <p className="text-xs text-gray-500">Gerado em 03/11/2023 09:10</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <button
                    className="p-1 rounded-full text-gray-400 hover:text-gray-500"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedReportId('fluxo_caixa');
                      exportReport('pdf');
                    }}
                  >
                    <Download className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Relatórios Agendados</h3>
          </div>
          <div className="divide-y divide-gray-200">
            <div className="p-4 hover:bg-gray-50">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10 rounded-md bg-green-100 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4 flex-1">
                  <h4 className="text-sm font-medium text-gray-900">Balanço Patrimonial Mensal</h4>
                  <p className="text-xs text-gray-500">
                    Todo dia 01 às 07:00 • Próximo: 01/12/2023
                  </p>
                </div>
                <div className="ml-2">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Ativo
                  </span>
                </div>
              </div>
            </div>
            <div className="p-4 hover:bg-gray-50">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10 rounded-md bg-blue-100 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4 flex-1">
                  <h4 className="text-sm font-medium text-gray-900">DRE Mensal</h4>
                  <p className="text-xs text-gray-500">
                    Todo dia 05 às 07:30 • Próximo: 05/12/2023
                  </p>
                </div>
                <div className="ml-2">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Ativo
                  </span>
                </div>
              </div>
            </div>
            <div className="p-4 hover:bg-gray-50">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10 rounded-md bg-purple-100 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-purple-600" />
                </div>
                <div className="ml-4 flex-1">
                  <h4 className="text-sm font-medium text-gray-900">Balancete Semanal</h4>
                  <p className="text-xs text-gray-500">
                    Toda segunda às 08:00 • Próximo: 13/11/2023
                  </p>
                </div>
                <div className="ml-2">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Ativo
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Report Viewer Dialog */}
      <Dialog 
        open={showReportViewer} 
        onOpenChange={setShowReportViewer}
      >
        <DialogContent className="max-w-6xl w-full">
          <DialogHeader>
            <DialogTitle>
              {selectedReportId === 'balanco' ? 'Balanço Patrimonial' :
               selectedReportId === 'dre' ? 'Demonstração do Resultado' :
               selectedReportId === 'fluxo_caixa' ? 'Fluxo de Caixa' :
               selectedReportId === 'balancete' ? 'Balancete' :
               reportTypes.find(r => r.id === selectedReportId)?.name || 'Visualizador de Relatório'}
            </DialogTitle>
          </DialogHeader>
          
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center">
              <RefreshCw className="h-12 w-12 text-amber-500 animate-spin mb-4" />
              <p className="text-gray-500">Gerando relatório, aguarde...</p>
            </div>
          ) : (
            <>
              <div className="py-4">
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <select
                        className="block pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm rounded-md"
                        value={dateRange}
                        onChange={(e) => setDateRange(e.target.value as any)}
                      >
                        <option value="day">Hoje</option>
                        <option value="week">Esta Semana</option>
                        <option value="month">Este Mês</option>
                        <option value="quarter">Este Trimestre</option>
                        <option value="year">Este Ano</option>
                        <option value="custom">Personalizado</option>
                      </select>
                    </div>
                    
                    <Button 
                      variant="outline"
                      size="sm"
                      onClick={() => {}}
                    >
                      <Filter className="h-4 w-4 mr-1" />
                      Filtros
                    </Button>
                    
                    <Button 
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setIsLoading(true);
                        setTimeout(() => {
                          setIsLoading(false);
                        }, 1000);
                      }}
                    >
                      <RefreshCw className="h-4 w-4 mr-1" />
                      Atualizar
                    </Button>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedReportId(selectedReportId);
                        exportReport('pdf');
                      }}
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <RefreshCw className="h-4 w-4 mr-1 animate-spin" />
                      ) : (
                        <Download className="h-4 w-4 mr-1" />
                      )}
                      PDF
                    </Button>
                    <Button 
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedReportId(selectedReportId);
                        exportReport('excel');
                      }}
                    >
                      <Download className="h-4 w-4 mr-1" />
                      Excel
                    </Button>
                    <Button 
                      variant="outline"
                      size="sm"
                      onClick={printReport}
                    >
                      <Printer className="h-4 w-4 mr-1" />
                      Imprimir
                    </Button>
                  </div>
                </div>
                
                <ReportViewer 
                  reportId={selectedReportId || ''} 
                  dateRange={dateRange}
                />
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Schedule Form Dialog */}
      <Dialog
        open={showScheduleForm}
        onOpenChange={setShowScheduleForm}
      >
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>
              Agendar Relatório: {reportTypes.find(r => r.id === selectedReportId)?.name}
            </DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <ReportScheduleForm 
              reportId={selectedReportId || ''}
              onSubmit={handleSaveSchedule}
              onCancel={() => setShowScheduleForm(false)}
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};