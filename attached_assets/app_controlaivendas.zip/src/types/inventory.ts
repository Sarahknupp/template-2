export interface InventoryItem {
  id: string;
  name: string;
  internalCode?: string;
  quantity: number;
  unit: string;
  minimumLevel: number;
  reorderPoint?: number;
  suggestedOrderQuantity?: number;
  expiryDate?: Date;
  purchaseDate: Date;
  costPerUnit: number;
  supplierId: string;
  location: string;
  lastUpdated: Date;
  lastRestockDate?: Date;
  needsRestock?: boolean;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
}

export interface IncomingGoods {
  id: string;
  invoiceNumber: string;
  invoiceBarcode?: string;
  supplier: string;
  date: Date;
  items: IncomingGoodsItem[];
  status: 'pending' | 'verified' | 'completed';
  totalAmount: number;
  notes?: string;
  attachments?: string[];
}

export interface IncomingGoodsItem {
  id: string;
  productId: string;
  productName: string;
  internalCode?: string;
  quantity: number;
  unitPrice: number;
  total: number;
  expiryDate?: Date;
}

export interface ShoppingListItem {
  id: string;
  internalCode?: string;
  name: string;
  currentQuantity: number;
  minimumQuantity: number;
  reorderPoint: number;
  suggestedOrderQuantity: number;
  unit: string;
  supplierId?: string;
  supplierName?: string;
  lastPurchasePrice?: number;
}