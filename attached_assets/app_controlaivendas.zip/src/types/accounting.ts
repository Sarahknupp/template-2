export interface Company {
  id: string;
  cnpj: string;
  companyName: string;
  tradeName: string;
  stateRegistration: string;
  municipalRegistration?: string;
  address: {
    street: string;
    number: string;
    complement?: string;
    district: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  phone: string;
  email: string;
  taxRegime: 'simples' | 'presumido' | 'real';
  economicActivity: string;
  cnae: string;
  openingDate: Date;
  accountingResponsible: string;
  status: 'active' | 'inactive' | 'suspended';
  branches: Branch[];
}

export interface Branch {
  id: string;
  cnpj: string;
  tradeName: string;
  stateRegistration: string;
  municipalRegistration?: string;
  address: {
    street: string;
    number: string;
    complement?: string;
    district: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  isHeadquarters: boolean;
}

export interface DigitalCertificate {
  id: string;
  companyId: string;
  serialNumber: string;
  issuer: string;
  validFrom: Date;
  validTo: Date;
  filename: string;
  password: string;
  status: 'valid' | 'expired' | 'revoked';
  type: 'a1' | 'a3';
  usedFor: ('nfe' | 'nfce' | 'cte' | 'mdfe' | 'efd')[];
}

export interface TaxParameters {
  id: string;
  companyId: string;
  year: number;
  icmsTaxRate: number;
  pisRate: number;
  cofinsRate: number;
  issRate: number;
  irrfRate: number;
  csllRate: number;
  inssRate: number;
  icmsSTRate?: number;
  icmsDeferredRate?: number;
  ipiRates: { ncm: string; rate: number }[];
  effectiveDate: Date;
  expirationDate?: Date;
  createdBy: string;
  updatedBy?: string;
  createdAt: Date;
  updatedAt?: Date;
}

export interface AccountingCode {
  id: string;
  code: string;
  description: string;
  type: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
  parentId?: string;
  companyId: string;
  isActive: boolean;
}

export interface FiscalDocument {
  id: string;
  companyId: string;
  number: string;
  serie: string;
  type: 'nfe' | 'nfce' | 'cte' | 'mdfe' | 'nfse';
  issueDate: Date;
  status: 'draft' | 'issued' | 'cancelled' | 'denied' | 'pending';
  customerDocument: string; // CNPJ or CPF
  customerName: string;
  totalAmount: number;
  taxAmount: number;
  items: FiscalDocumentItem[];
  paymentMethod: 'cash' | 'credit' | 'debit' | 'pix' | 'bank_transfer' | 'check';
  accessKey?: string;
  protocol?: string;
  cancelledAt?: Date;
  cancelProtocol?: string;
  xmlContent?: string;
  createdBy: string;
  observations?: string;
  authorizedAt?: Date;
  deniedReason?: string;
}

export interface FiscalDocumentItem {
  id: string;
  documentId: string;
  productId: string;
  productCode: string;
  description: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  ncm: string;
  cfop: string;
  icmsBaseValue?: number;
  icmsValue?: number;
  icmsRate?: number;
  pisBaseValue?: number;
  pisValue?: number;
  pisRate?: number;
  cofinsBaseValue?: number;
  cofinsValue?: number;
  cofinsRate?: number;
  ipiBaseValue?: number;
  ipiValue?: number;
  ipiRate?: number;
  origin?: string;
}

export interface SpedFile {
  id: string;
  companyId: string;
  type: 'fiscal' | 'contributions' | 'accounting';
  reference: string; // Format YYYY-MM for monthly, YYYY for yearly
  generationDate: Date;
  status: 'generating' | 'generated' | 'validated' | 'transmitted' | 'error';
  transmissionDate?: Date;
  protocol?: string;
  errorMessage?: string;
  fileName: string;
  fileSize: number;
  createdBy: string;
  validationMessages?: SpedValidationMessage[];
}

export interface SpedValidationMessage {
  id: string;
  spedFileId: string;
  block: string;
  record: string;
  field: string;
  message: string;
  type: 'error' | 'warning' | 'info';
}

export interface TaxObligation {
  id: string;
  companyId: string;
  name: string;
  type: 'federal' | 'state' | 'municipal';
  dueDate: Date;
  amount: number;
  status: 'pending' | 'paid' | 'late';
  description: string;
  reference: string; // Format YYYY-MM
  paymentDate?: Date;
  document?: string; // Path to the document
  reminderDate: Date;
  createdBy: string;
}

export interface AccountingReport {
  id: string;
  companyId: string;
  type: 'balance_sheet' | 'income_statement' | 'cash_flow' | 'trial_balance' | 'ledger' | 'custom';
  name: string;
  periodStart: Date;
  periodEnd: Date;
  generationDate: Date;
  status: 'generated' | 'generating' | 'error';
  filePath?: string;
  parameters?: Record<string, any>;
  createdBy: string;
}

export interface CertificateStatus {
  companyId: string;
  totalCertificates: number;
  validCertificates: number;
  expiringCertificates: number; // Expiring in the next 30 days
  expiredCertificates: number;
}

export interface TaxObligationSummary {
  companyId: string;
  pendingObligations: number;
  paidObligations: number;
  lateObligations: number;
  nextDueDates: { name: string; dueDate: Date; amount: number }[];
  totalDue: number;
}

export interface DocumentSummary {
  companyId: string;
  totalDocuments: number;
  issuedDocuments: number;
  cancelledDocuments: number;
  pendingDocuments: number;
  errorDocuments: number;
  lastDocuments: { number: string; type: string; customerName: string; totalAmount: number; issueDate: Date }[];
}