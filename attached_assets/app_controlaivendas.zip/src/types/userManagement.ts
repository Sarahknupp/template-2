export interface UserRole {
  id: string;
  name: string;
  permissions: string[];
  description: string;
}

export interface UserAuditLog {
  id: string;
  userId: string;
  action: 'create' | 'update' | 'delete' | 'login' | 'logout' | 'password_change' | 'role_change' | 'status_change';
  performedBy: string;
  timestamp: Date;
  details?: string;
  ipAddress?: string;
}

export interface UserAccount {
  id: string;
  username: string;
  email: string;
  passwordHash: string;
  fullName: string;
  roleId: string;
  roleName: string;
  isActive: boolean;
  lastLogin?: Date;
  createdAt: Date;
  updatedAt: Date;
  createdBy?: string;
  updatedBy?: string;
  requirePasswordChange?: boolean;
  failedLoginAttempts?: number;
  lockedUntil?: Date;
}

export interface PasswordChangeRequest {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export interface PasswordComplexityResult {
  valid: boolean;
  hasMinLength: boolean;
  hasUpperCase: boolean;
  hasLowerCase: boolean;
  hasNumber: boolean;
  hasSpecialChar: boolean;
  score: number;
}

export interface UserFilter {
  search?: string;
  role?: string;
  status?: 'active' | 'inactive' | 'all';
  sortBy?: 'username' | 'email' | 'fullName' | 'roleName' | 'lastLogin' | 'createdAt';
  sortDirection?: 'asc' | 'desc';
}

export interface BulkAction {
  ids: string[];
  action: 'activate' | 'deactivate' | 'delete' | 'changeRole';
  roleId?: string;
}