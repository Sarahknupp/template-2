export interface ProductionPlan {
  id: string;
  date: Date;
  products: ProductionItem[];
  status: 'planned' | 'in-progress' | 'completed';
  assignedTo: string;
  area: 'kitchen' | 'confectionery' | 'bakery';
  priority: 'low' | 'medium' | 'high';
  linkedOrders?: string[];
  estimatedTimeMinutes: number;
  actualTimeMinutes?: number;
  notes?: string;
}

export interface ProductionItem {
  productId: string;
  productName: string;
  quantity: number;
  completed: number;
  wasted: number;
}

export interface ProductionArea {
  id: string;
  name: string;
  description: string;
  productionCapacity: number; // items per day
  currentUtilization: number; // percentage
  activeProduction: string[]; // array of production IDs
  equipment: Equipment[];
}

export interface Equipment {
  id: string;
  name: string;
  type: string;
  status: 'active' | 'maintenance' | 'out-of-service';
  lastMaintenance?: Date;
}

export interface TechnicalSheet {
  id: string;
  productId: string;
  productName: string;
  area: 'kitchen' | 'confectionery' | 'bakery';
  specificInstructions: string[];
  temperatureControl?: {
    min: number;
    max: number;
    unit: 'C' | 'F';
  };
  fermentationTime?: number; // in minutes
  bakingTime?: number; // in minutes
  decorationDetails?: string;
  shelfLife: number; // in hours
  preparationSteps: PreparationStep[];
}

export interface PreparationStep {
  id: string;
  order: number;
  description: string;
  estimatedTime: number; // in minutes
  equipmentNeeded?: string[];
  temperatureNeeded?: number;
  imageUrl?: string;
}

export interface ProductionOrder {
  id: string;
  orderNumber: string;
  date: Date;
  dueDate: Date;
  clientName?: string;
  clientId?: string;
  status: 'pending' | 'in-production' | 'completed' | 'delivered' | 'cancelled';
  priority: 'low' | 'medium' | 'high';
  items: ProductionOrderItem[];
  notes?: string;
  saleId?: string; // reference to the sale that originated this order
  totalEstimatedTime: number; // in minutes
  assignedArea: 'kitchen' | 'confectionery' | 'bakery' | 'multiple';
  createdBy: string; // user ID
  trackingEvents: TrackingEvent[];
}

export interface ProductionOrderItem {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  status: 'pending' | 'in-production' | 'completed';
  area: 'kitchen' | 'confectionery' | 'bakery';
  technicalSheetId: string;
  estimatedTime: number; // in minutes
  startTime?: Date;
  endTime?: Date;
}

export interface TrackingEvent {
  id: string;
  timestamp: Date;
  description: string;
  userId: string;
  userName: string;
  status: string;
  notes?: string;
}

// Specific models for each production area
export interface KitchenPreparation {
  id: string;
  name: string;
  isHot: boolean; // Hot preparation or cold
  cookingTime: number; // in minutes
  cookingTemperature?: number;
  ingredients: RequiredIngredient[];
  instructions: string[];
  servingSize: number;
  equipmentNeeded: string[];
}

export interface ConfectioneryItem {
  id: string;
  name: string;
  standardizedRecipe: string;
  temperatureControl: {
    min: number;
    max: number;
  };
  decorationItems: string[];
  expirationHours: number;
  storageInstructions: string;
  ingredients: RequiredIngredient[];
}

export interface BakeryItem {
  id: string;
  name: string;
  doughType: string;
  fermentationTime: number; // in minutes
  fermentationTemperature: number;
  ovenTime: number; // in minutes
  ovenTemperature: number;
  batchSize: number;
  ingredients: RequiredIngredient[];
  shelfLife: number; // in hours
}

export interface RequiredIngredient {
  id: string;
  inventoryItemId: string;
  name: string;
  quantity: number;
  unit: string;
}

export interface ProductivityReport {
  periodStart: Date;
  periodEnd: Date;
  areas: AreaProductivity[];
  totalProduction: number;
  totalPlanned: number;
  completionRate: number;
  wasteRate: number;
  averageProductionTime: number;
}

export interface AreaProductivity {
  area: 'kitchen' | 'confectionery' | 'bakery';
  itemsProduced: number;
  itemsWasted: number;
  efficiencyRate: number; // percentage
  avgCompletionTime: number; // in minutes
  topProducedItems: { productId: string; productName: string; quantity: number }[];
}