export interface ReportType {
  id: string;
  name: string;
  category: 'financial' | 'inventory' | 'production' | 'sales' | 'operations' | 'administrative' | 'fiscal';
  description: string;
  formats: ('pdf' | 'excel' | 'csv' | 'email')[];
  defaultFormat: 'pdf' | 'excel' | 'csv' | 'email';
  availableFrequencies: ('daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly' | 'custom')[];
  permissions: string[];
  parameters: ReportParameter[];
  columns: ReportColumn[];
  charts?: ReportChart[];
  subReports?: string[];
}

export interface ReportParameter {
  id: string;
  type: 'date' | 'date_range' | 'select' | 'multi_select' | 'boolean' | 'number' | 'text';
  label: string;
  required: boolean;
  options?: { value: string; label: string }[];
  source?: string;
  filter?: Record<string, any>;
  defaultValue?: any;
  minValue?: number;
  maxValue?: number;
}

export interface ReportColumn {
  id: string;
  name: string;
  required: boolean;
}

export interface ReportChart {
  type: 'bar' | 'line' | 'pie' | 'scatter' | 'area' | 'radar';
  title: string;
  dataKey: string;
}

export interface ReportSchedule {
  id: string;
  reportId: string;
  name: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'custom';
  dayOfWeek?: number; // 0 (Sunday) to 6 (Saturday), for weekly
  dayOfMonth?: number; // 1-31, for monthly
  time: string; // HH:MM format
  lastRun: Date;
  nextRun: Date;
  status: 'active' | 'inactive' | 'error';
  recipients: string[];
  format: 'pdf' | 'excel' | 'csv' | 'email';
  parameters: Record<string, any>;
  createdBy: string;
  createdAt: Date;
  error?: string;
}

export type ReportParameters = {
  name: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'custom';
  dayOfWeek?: number;
  dayOfMonth?: number;
  time: string;
  format: string;
  recipients: string[];
  parameters: Record<string, any>;
};

export interface ReportExecution {
  id: string;
  scheduleId?: string;
  reportId: string;
  startTime: Date;
  endTime?: Date;
  status: 'running' | 'completed' | 'failed';
  parameters: Record<string, any>;
  outputFormat: string;
  outputPath?: string;
  errorMessage?: string;
  executedBy: string;
}

export interface ReportCache {
  id: string;
  reportId: string;
  parameters: string; // JSON stringified parameters
  data: string; // JSON stringified data
  createdAt: Date;
  expiresAt: Date;
}

export interface ReportEmailConfig {
  from: string;
  smtpServer: string;
  smtpPort: number;
  username: string;
  password: string;
  useSsl: boolean;
  defaultSubject: string;
  defaultBody: string;
}

export interface ReportStorageConfig {
  provider: 'local' | 's3' | 'gcs' | 'azure' | 'dropbox';
  bucket?: string;
  basePath: string;
  credentials?: Record<string, any>;
  retentionDays: number;
}

export interface ReportPermission {
  reportId: string;
  roleId: string;
  canView: boolean;
  canSchedule: boolean;
  canExport: boolean;
  canCreate: boolean;
}

export interface ReportNotification {
  id: string;
  scheduleId?: string;
  reportId: string;
  type: 'scheduled' | 'failure' | 'threshold_alert';
  recipients: string[];
  message?: string;
  status: 'pending' | 'sent' | 'failed';
  createdAt: Date;
  sentAt?: Date;
  thresholdValue?: number;
  thresholdCondition?: 'greater_than' | 'less_than' | 'equal_to' | 'not_equal_to';
}