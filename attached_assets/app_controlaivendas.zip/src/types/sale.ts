export interface Sale {
  id: string;
  date: Date;
  items: SaleItem[];
  subtotal: number;
  tax: number;
  total: number;
  paymentMethod: 'cash' | 'credit' | 'debit' | 'other';
  status: 'completed' | 'refunded' | 'canceled';
  cashierId: string;
  customerDetails?: {
    name?: string;
    phone?: string;
    email?: string;
  };
}

export interface SaleItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  total: number;
}